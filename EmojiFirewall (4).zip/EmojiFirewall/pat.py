
from pathlib import Path
from datetime import datetime
import shutil
import sys

path = Path(r"J:\EmojiFirewall\Install-WebSentinel-Wiring.ps1")
text = path.read_text(encoding="utf-8-sig")

duplicate = '''$content = Replace-Once $content @'
console.warn("[COOKIE_GUARD] document.cookie write blocked", value);
'@ @'
if (!firewallOn("cookieBlocking")) {
    return desc.set.call(this, value);
}
if (loggingOn("cookieEvents")) {
    console.warn("[COOKIE_GUARD] document.cookie write blocked");
}
'@ 'document.cookie switch'
'''

count = text.count(duplicate)

if count != 1:
    print(f"Expected exactly one duplicate block; found {count}.")
    print("No changes made.")
    sys.exit(1)

backup = path.with_name(
    path.name + ".bak-" + datetime.now().strftime("%Y%m%d-%H%M%S")
)
shutil.copy2(path, backup)

text = text.replace(duplicate, "", 1)
path.write_text(text, encoding="utf-8")

print(f"Removed duplicate cookie replacement block.")
print(f"Installer: {path}")
print(f"Backup:    {backup}")