$ErrorActionPreference = 'Stop'

$HomeDir = 'J:\EmojiFirewall\WebSentinelLauncher'
$ExtDir  = 'J:\EmojiFirewall\BrowserExtension'
$ProxyDir = 'J:\EmojiFirewall\SidebarFirewall'
$SettingsPath = Join-Path $HomeDir 'settings.json'
$Stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$BackupDir = Join-Path $HomeDir "backups\wiring-$Stamp"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function Read-Text([string]$Path) {
    return [System.IO.File]::ReadAllText($Path)
}
function Write-Text([string]$Path, [string]$Text) {
    [System.IO.File]::WriteAllText($Path, $Text, $Utf8NoBom)
}

$Targets = @(
    (Join-Path $HomeDir 'WebSentinel-Settings.ps1'),
    (Join-Path $ExtDir 'manifest.json'),
    (Join-Path $ExtDir 'content.js'),
    (Join-Path $ExtDir 'request-guard.js'),
    (Join-Path $ExtDir 'sentinel-policy.js'),
    (Join-Path $ProxyDir 'Program.cs'),
    (Join-Path $ProxyDir 'CookiePolicy.cs')
)

foreach ($p in $Targets) {
    if (-not (Test-Path -LiteralPath $p -PathType Leaf)) {
        throw "Required file not found: $p"
    }
}
if (-not (Test-Path -LiteralPath $SettingsPath -PathType Leaf)) {
    throw "Settings file not found: $SettingsPath"
}

# Validate settings.json: every key the wiring reads must exist.
$settings = (Read-Text $SettingsPath) | ConvertFrom-Json
$required = @{
    firewall = @('enabled', 'emojiFiltering', 'sidebarFiltering', 'psnProtection',
                 'oobProtection', 'cookieBlocking', 'domFiltering',
                 'networkRequestFirewall', 'adTrackerBlocking', 'urlFiltering',
                 'suspiciousUnicodeBlocking')
    logging  = @('enabled', 'cookieEvents', 'proxyActivity')
}
foreach ($section in $required.Keys) {
    if ($null -eq $settings.$section) {
        throw "Settings are missing the '$section' section."
    }
    foreach ($key in $required[$section]) {
        if ($null -eq $settings.$section.$key) {
            throw "Settings are missing '$section.$key'."
        }
    }
}

# Anchor replacement: whitespace/indent/line-ending tolerant, must match exactly once.
function Replace-Once {
    param(
        [string]$Text,
        [string]$Old,
        [string]$New,
        [string]$Label
    )
    $tokens = [regex]::Split($Old.Trim(), '\s+') | ForEach-Object { [regex]::Escape($_) }
    $pattern = $tokens -join '\s+'
    $found = [regex]::Matches($Text, $pattern)
    if ($found.Count -eq 0) {
        throw "Preflight failed: anchor not found ($Label). Nothing was written."
    }
    if ($found.Count -gt 1) {
        throw "Preflight failed: anchor is not unique ($Label). Nothing was written."
    }
    $m = $found[0]
    $nl = if ($Text.Contains("`r`n")) { "`r`n" } else { "`n" }
    $replacement = ($New.TrimStart() -replace "`r?`n", $nl)
    return $Text.Substring(0, $m.Index) + $replacement +
        $Text.Substring($m.Index + $m.Length)
}

# Read everything as UTF-8 (Get-Content in PS 5.1 reads BOM-less UTF-8 as ANSI and corrupts emoji).
$gui = Read-Text $Targets[0]
$manifestText = Read-Text $Targets[1]
$content = Read-Text $Targets[2]
$requestGuard = Read-Text $Targets[3]
$domPolicy = Read-Text $Targets[4]
$program = Read-Text $Targets[5]
$cookiePolicy = Read-Text $Targets[6]

# Re-run guard: every New block contains its Old block, so a second run would double-insert.
if ($content.Contains('webSentinelSettings') -or
    $requestGuard.Contains('webSentinelSettings') -or
    $domPolicy.Contains('webSentinelSettings')) {
    throw "Wiring is already installed. Restore from backups\ before re-running."
}

# 1. GUI: publish settings for the extension whenever Save is clicked.
$gui = Replace-Once $gui @'
Move-Item -LiteralPath $TemporaryPath `
    -Destination $ConfigPath -Force
'@ @'
Move-Item -LiteralPath $TemporaryPath `
    -Destination $ConfigPath -Force

Copy-Item -LiteralPath $ConfigPath `
    -Destination 'J:\EmojiFirewall\BrowserExtension\sentinel-runtime-settings.json' -Force
'@ 'GUI settings publisher'

# 2. Extension-side settings bridge (written at the end).
$bridge = @'
"use strict";

(async function () {
    const KEY = "webSentinelSettings";
    let last = "";

    async function refresh() {
        try {
            const response = await fetch(
                browser.runtime.getURL("sentinel-runtime-settings.json"),
                { cache: "no-store" }
            );
            if (!response.ok) throw new Error("HTTP " + response.status);

            const settings = await response.json();
            if (!settings.firewall || !settings.logging) {
                throw new Error("Invalid settings structure");
            }

            const serialized = JSON.stringify(settings);
            if (serialized !== last) {
                await browser.storage.local.set({ [KEY]: settings });
                last = serialized;
            }
        } catch (e) {
            console.error("[Web Sentinel settings bridge]", String(e));
        }
    }

    await refresh();
    setInterval(refresh, 1000);
})();
'@

# 3. Manifest: textual insert (keeps formatting, no BOM, no \u003c escaping).
$manifestObj = $manifestText | ConvertFrom-Json
if ($manifestObj.permissions -notcontains 'storage') {
    throw "manifest.json must declare the 'storage' permission."
}
if (-not $manifestObj.background.scripts -or $manifestObj.background.scripts.Count -lt 1) {
    throw "manifest.json has no non-empty background.scripts array."
}
if ($manifestObj.background.scripts -notcontains 'settings-bridge.js') {
    $rx = [regex]'("scripts"\s*:\s*\[)'
    if ($rx.Matches($manifestText).Count -ne 1) {
        throw "Preflight failed: manifest background scripts anchor not unique/found."
    }
    $manifestText = $rx.Replace($manifestText, '$1"settings-bridge.js", ', 1)
    $null = $manifestText | ConvertFrom-Json
}

# 4. content.js (fails closed until settings load, matching pre-wiring behavior).
$content = Replace-Once $content @'
    "use strict";
'@ @'
    "use strict";

    let runtimeSettings = null;
    const storageApi = globalThis.browser?.storage ?? globalThis.chrome?.storage;

    function firewallOn(key) {
        if (runtimeSettings === null) return true;
        return runtimeSettings.firewall?.enabled === true &&
               runtimeSettings.firewall?.[key] === true;
    }

    function loggingOn(key) {
        return runtimeSettings?.logging?.enabled === true &&
               runtimeSettings?.logging?.[key] === true;
    }

    if (storageApi?.local) {
        Promise.resolve(storageApi.local.get("webSentinelSettings"))
            .then(result => {
                runtimeSettings = result.webSentinelSettings || null;
            })
            .catch(() => {});

        storageApi.onChanged?.addListener((changes, area) => {
            if (area === "local" && changes.webSentinelSettings) {
                runtimeSettings = changes.webSentinelSettings.newValue || null;
            }
        });
    }
'@ 'content settings helper'

$content = Replace-Once $content @'
      console.warn("[COOKIE_GUARD] document.cookie write blocked", value);
      // write is dropped
'@ @'
      if (!firewallOn("cookieBlocking")) {
        return desc.set.call(this, value);
      }
      if (loggingOn("cookieEvents")) {
        console.warn("[COOKIE_GUARD] document.cookie write blocked");
      }
      // write is dropped; cookie values are never logged
'@ 'document.cookie switch'

$content = Replace-Once $content @'
    function transformText(text) {
        if (!text)
'@ @'
    function transformText(text) {
        if (!firewallOn("emojiFiltering") || !text)
'@ 'emoji filtering switch'

$content = Replace-Once $content @'
function neutralizeSvgTree(root) {
    if (!(root instanceof Node))
'@ @'
function neutralizeSvgTree(root) {
    if (!firewallOn("emojiFiltering") || !(root instanceof Node))
'@ 'SVG filtering switch'

$content = Replace-Once $content @'
    function removeWhatsHappening() {
        if (location.hostname !== "x.com" &&
'@ @'
    function removeWhatsHappening() {
        if (!firewallOn("sidebarFiltering")) return;

        if (location.hostname !== "x.com" &&
'@ 'sidebar filtering switch'

$content = Replace-Once $content @'
        function inspectField(event) {
            const el = event.target;
'@ @'
        function inspectField(event) {
            if (!firewallOn("psnProtection")) return;
            const el = event.target;
'@ 'PSN input inspection switch'

$content = Replace-Once $content @'
        function enforceOptInByteLimit(event) {
            const form = event.target;
'@ @'
        function enforceOptInByteLimit(event) {
            if (!firewallOn("oobProtection")) return;
            const form = event.target;
'@ 'OOB byte limit switch'

$content = Replace-Once $content @'
        document.addEventListener("submit", function blockSuspiciousSubmission(event) {
            const form = event.target;
'@ @'
        document.addEventListener("submit", function blockSuspiciousSubmission(event) {
            if (!firewallOn("psnProtection")) return;
            const form = event.target;
'@ 'PSN submission switch'

# 5. DOM selector enforcement.
$domPolicy = Replace-Once $domPolicy @'
    const PREFIX = "[Web Sentinel]";
'@ @'
    const PREFIX = "[Web Sentinel]";
    let runtimeSettings = null;
    const settingsStorage = globalThis.browser?.storage ?? globalThis.chrome?.storage;

    function domFilteringOn() {
        if (runtimeSettings === null) return true;
        return runtimeSettings.firewall?.enabled === true &&
               runtimeSettings.firewall?.domFiltering === true;
    }

    if (settingsStorage?.local) {
        Promise.resolve(settingsStorage.local.get("webSentinelSettings"))
            .then(result => {
                runtimeSettings = result.webSentinelSettings || null;
            }).catch(() => {});
        settingsStorage.onChanged?.addListener((changes, area) => {
            if (area === "local" && changes.webSentinelSettings) {
                runtimeSettings = changes.webSentinelSettings.newValue || null;
            }
        });
    }
'@ 'DOM settings helper'

$domPolicy = Replace-Once $domPolicy @'
    function scan(root) {
        if (!configLoaded || !root)
'@ @'
    function scan(root) {
        if (!domFilteringOn() || !configLoaded || !root)
'@ 'DOM filtering switch'

# 6. Request guard.
$requestGuard = Replace-Once $requestGuard @'
    let rules;
'@ @'
    let rules;
    let runtimeSettings = null;

    function firewallOn(key) {
        if (runtimeSettings === null) return true;
        return runtimeSettings.firewall?.enabled === true &&
               runtimeSettings.firewall?.[key] === true;
    }

    function loggingOn(key) {
        return runtimeSettings?.logging?.enabled === true &&
               runtimeSettings?.logging?.[key] === true;
    }

    browser.storage.local.get("webSentinelSettings").then(result => {
        runtimeSettings = result.webSentinelSettings || null;
    }).catch(() => {});

    browser.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && changes.webSentinelSettings) {
            runtimeSettings = changes.webSentinelSettings.newValue || null;
        }
    });
'@ 'request guard settings helper'

$requestGuard = Replace-Once $requestGuard @'
            function (details) {
                try {
                    const decision = globalThis.WebSentinelPolicy.evaluate({
'@ @'
            function (details) {
                try {
                    if (runtimeSettings !== null &&
                        runtimeSettings.firewall?.enabled !== true) return {};

                    const policyRules = {
                        ...rules,
                        domains: firewallOn("networkRequestFirewall")
                            ? rules.domains
                            : { block: [], allow: [] },
                        adsAndTrackers: {
                            ...rules.adsAndTrackers,
                            enabled: firewallOn("adTrackerBlocking") &&
                                     rules.adsAndTrackers?.enabled !== false
                        },
                        urls: firewallOn("urlFiltering")
                            ? rules.urls
                            : { blockPatterns: [], allowPatterns: [] },
                        headers: firewallOn("networkRequestFirewall")
                            ? rules.headers
                            : { required: [], blockedNames: [], maxCount: 100000, maxValueLength: 1000000 },
                        contentTypes: firewallOn("networkRequestFirewall")
                            ? rules.contentTypes
                            : { block: [] },
                        limits: firewallOn("networkRequestFirewall")
                            ? rules.limits
                            : { maxUrlLength: 1000000, maxHeaderCount: 1000000 }
                    };

                    const decision = globalThis.WebSentinelPolicy.evaluate({
'@ 'network request feature gates'

$requestGuard = Replace-Once $requestGuard @'
                    }, rules);

                    if (decision.decision === "block" ||
'@ @'
                    }, policyRules);

                    if (decision.decision === "block" ||
'@ 'effective policy argument'

$requestGuard = Replace-Once $requestGuard @'
                    if (inspectBody(details.requestBody)) {
'@ @'
                    if (firewallOn("suspiciousUnicodeBlocking") &&
                        inspectBody(details.requestBody)) {
'@ 'request Unicode switch'

$requestGuard = Replace-Once $requestGuard @'
    async function isDomainAllowed(hostname) {
'@ @'
    async function isDomainAllowed(hostname) {
      if (!firewallOn("cookieBlocking")) return true;
'@ 'cookie response switch'

$requestGuard = Replace-Once $requestGuard @'
    async (details) => {
      try {
        const url = new URL(details.url);
'@ @'
    async (details) => {
      try {
        if (!firewallOn("cookieBlocking")) return;
        const url = new URL(details.url);
'@ 'cookie response listener switch'

# 7. C# settings reader (cached by file timestamp, not re-parsed per request).
$settingsClass = @'
using System;
using System.IO;
using System.Text.Json.Nodes;

internal static class FirewallSettings
{
    private const string ConfigPath =
        @"J:\EmojiFirewall\WebSentinelLauncher\settings.json";

    private static readonly object Gate = new object();
    private static DateTime _stamp = DateTime.MinValue;
    private static JsonNode? _root;

    // Firewall switches fail closed (on); logging fails off.
    public static bool FirewallEnabled(string key) =>
        Read("firewall", "enabled", true) && Read("firewall", key, true);

    public static bool LoggingEnabled(string key) =>
        Read("logging", "enabled", false) && Read("logging", key, false);

    private static bool Read(string section, string key, bool fallback)
    {
        try
        {
            lock (Gate)
            {
                var stamp = File.GetLastWriteTimeUtc(ConfigPath);
                if (_root is null || stamp != _stamp)
                {
                    _root = JsonNode.Parse(File.ReadAllText(ConfigPath));
                    _stamp = stamp;
                }
                var value = _root?[section]?[key];
                return value is null ? fallback : value.GetValue<bool>();
            }
        }
        catch
        {
            return fallback;
        }
    }
}

internal static class CookieLog
{
    public static void WriteLine(string message)
    {
        if (FirewallSettings.LoggingEnabled("cookieEvents"))
            Console.WriteLine(message);
    }

    public static void WriteLine(string format, params object?[] args)
    {
        if (FirewallSettings.LoggingEnabled("cookieEvents"))
            Console.WriteLine(format, args);
    }
}
'@

$program = Replace-Once $program @'
        if (uri is not null &&
            (uri.Host.Equals("x.com", StringComparison.OrdinalIgnoreCase) ||
'@ @'
        if (FirewallSettings.LoggingEnabled("proxyActivity") &&
            uri is not null &&
            (uri.Host.Equals("x.com", StringComparison.OrdinalIgnoreCase) ||
'@ 'proxy activity logging gate'

$program = Replace-Once $program @'
            if (uri is null ||
                !string.Equals(uri.Host, "x.com",
'@ @'
            if (!FirewallSettings.FirewallEnabled("sidebarFiltering") ||
                uri is null ||
                !string.Equals(uri.Host, "x.com",
'@ 'proxy sidebar switch'

# 8. C# cookie enforcement and cookie event logs.
$cookiePolicy = Replace-Once $cookiePolicy @'
    {
        var cookies = response.Headers.GetHeaders("Set-Cookie")?.ToList();
'@ @'
    {
        if (!FirewallSettings.FirewallEnabled("cookieBlocking")) return;

        var cookies = response.Headers.GetHeaders("Set-Cookie")?.ToList();
'@ 'proxy cookie enforcement switch'

$cookiePolicy = Replace-Once $cookiePolicy @'
    {
        var hdr = request.Headers.GetFirstHeader("Cookie");
'@ @'
    {
        if (!FirewallSettings.LoggingEnabled("cookieEvents")) return;

        var hdr = request.Headers.GetFirstHeader("Cookie");
'@ 'proxy request cookie log switch'

# Drop-in call-target swap: preserves if/else structure around each call.
$cookiePolicy = $cookiePolicy.Replace('Console.WriteLine(', 'CookieLog.WriteLine(')

# ---- All anchors validated in memory. Only now touch disk. ----
New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
foreach ($p in $Targets) {
    Copy-Item -LiteralPath $p -Destination $BackupDir
}
Write-Host "Backups created: $BackupDir"

try {
    Write-Text $Targets[0] $gui
    Write-Text $Targets[1] $manifestText
    Write-Text $Targets[2] $content
    Write-Text $Targets[3] $requestGuard
    Write-Text $Targets[4] $domPolicy
    Write-Text $Targets[5] $program
    Write-Text $Targets[6] $cookiePolicy
    Write-Text (Join-Path $ExtDir 'settings-bridge.js') $bridge
    Write-Text (Join-Path $ProxyDir 'FirewallSettings.cs') $settingsClass
    Copy-Item -LiteralPath $SettingsPath `
        -Destination (Join-Path $ExtDir 'sentinel-runtime-settings.json') -Force
}
catch {
    foreach ($p in $Targets) {
        Copy-Item -LiteralPath (Join-Path $BackupDir (Split-Path $p -Leaf)) `
            -Destination $p -Force
    }
    throw
}

Write-Host ''
Write-Host 'Web Sentinel settings wiring installed.' -ForegroundColor Green
Write-Host "Backups: $BackupDir"
Write-Host 'Next: rebuild SidebarFirewall and restart Web Sentinel / Firefox.'