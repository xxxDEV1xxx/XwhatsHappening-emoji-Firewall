﻿
$ErrorActionPreference = 'Stop'

$HomePath = 'J:\EmojiFirewall\WebSentinelLauncher'
$SettingsPath = Join-Path $HomePath 'settings.json'
$GuiPath = Join-Path $HomePath 'WebSentinel-Settings.ps1'

if (-not (Test-Path -LiteralPath $HomePath -PathType Container)) {
throw "Web Sentinel launcher directory not found: $HomePath"
}

$Defaults = [ordered]@{
firewall = [ordered]@{
enabled = $true
emojiFiltering = $true
sidebarFiltering = $true
oobProtection = $true
psnProtection = $true
cookieBlocking = $true
networkRequestFirewall = $true
adTrackerBlocking = $true
urlFiltering = $true
suspiciousUnicodeBlocking = $true
domFiltering = $true
}
logging = [ordered]@{
enabled = $false
dns = $true
tcpHandshakes = $true
tlsHandshakes = $true
incomingConnections = $true
proxyActivity = $true
firewallDecisions = $true
cookieEvents = $true
oobPsnEvents = $true
extensionDiagnostics = $true
}
}

# Preserve existing selections, if any.

$Current = $null
if (Test-Path -LiteralPath $SettingsPath) {
try {
$Current = Get-Content -LiteralPath $SettingsPath -Raw |
ConvertFrom-Json
}
catch {
$Backup = "$SettingsPath.invalid-$(Get-Date -Format 'yyyyMMdd-HHmmss').bak"
Copy-Item -LiteralPath $SettingsPath -Destination $Backup
Write-Warning "Invalid settings backed up to $Backup"
}
}

$Merged = [ordered]@{}
foreach ($Section in @('firewall', 'logging')) {
$Merged[$Section] = [ordered]@{}

foreach ($Key in $Defaults[$Section].Keys) {
    $Value = $Defaults[$Section][$Key]
    $ExistingSection = if ($null -ne $Current) {
        $Current.PSObject.Properties[$Section].Value
    } else {
        $null
    }

    if ($null -ne $ExistingSection) {
        $ExistingProperty = $ExistingSection.PSObject.Properties[$Key]
        if ($null -ne $ExistingProperty) {
            $Value = [bool]$ExistingProperty.Value
        }
    }

    $Merged[$Section][$Key] = $Value
}

}

$Merged | ConvertTo-Json -Depth 8 |
Set-Content -LiteralPath $SettingsPath -Encoding UTF8

$Gui = @'
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$BasePath = 'J:\EmojiFirewall\WebSentinelLauncher'
$ConfigPath = Join-Path $BasePath 'settings.json'

$Defaults = [ordered]@{
firewall = [ordered]@{
enabled = $true
emojiFiltering = $true
sidebarFiltering = $true
oobProtection = $true
psnProtection = $true
cookieBlocking = $true
networkRequestFirewall = $true
adTrackerBlocking = $true
urlFiltering = $true
suspiciousUnicodeBlocking = $true
domFiltering = $true
}
logging = [ordered]@{
enabled = $false
dns = $true
tcpHandshakes = $true
tlsHandshakes = $true
incomingConnections = $true
proxyActivity = $true
firewallDecisions = $true
cookieEvents = $true
oobPsnEvents = $true
extensionDiagnostics = $true
}
}

$Checks = @{}

function Read-Config {
$Existing = $null

if (Test-Path -LiteralPath $ConfigPath) {
    try {
        $Existing = Get-Content -LiteralPath $ConfigPath -Raw |
            ConvertFrom-Json
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            "Settings file could not be parsed:`r`n$($_.Exception.Message)",
            'Web Sentinel Settings',
            'OK',
            'Error'
        ) | Out-Null
    }
}

$Result = [ordered]@{}
foreach ($Section in @('firewall', 'logging')) {
    $Result[$Section] = [ordered]@{}

    foreach ($Key in $Defaults[$Section].Keys) {
        $Value = $Defaults[$Section][$Key]
        $ExistingSection = if ($null -ne $Existing) {
            $Existing.PSObject.Properties[$Section].Value
        } else {
            $null
        }

        if ($null -ne $ExistingSection) {
            $Property = $ExistingSection.PSObject.Properties[$Key]
            if ($null -ne $Property) {
                $Value = [bool]$Property.Value
            }
        }

        $Result[$Section][$Key] = $Value
    }
}

return $Result

}

function Save-Config($Data) {
$TemporaryPath = "$ConfigPath.tmp"
$Data | ConvertTo-Json -Depth 8 |
Set-Content -LiteralPath $TemporaryPath -Encoding UTF8

Move-Item -LiteralPath $TemporaryPath `
    -Destination $ConfigPath -Force

}

function Add-CheckBox {
param(
[System.Windows.Forms.Control]$Parent,
[string]$Section,
[string]$Key,
[string]$Caption,
[int]$X,
[int]$Y,
[int]$Width = 310
)

$Check = New-Object System.Windows.Forms.CheckBox
$Check.Text = $Caption
$Check.Location = New-Object System.Drawing.Point($X, $Y)
$Check.Size = New-Object System.Drawing.Size($Width, 25)
$Check.AutoEllipsis = $true

$Parent.Controls.Add($Check)
$Checks["$Section.$Key"] = $Check

}

function Load-Controls($Data) {
foreach ($Section in @('firewall', 'logging')) {
foreach ($Key in $Defaults[$Section].Keys) {
$Checks["$Section.$Key"].Checked =
[bool]$Data[$Section][$Key]
}
}
}

function Collect-Controls {
$Data = [ordered]@{}

foreach ($Section in @('firewall', 'logging')) {
    $Data[$Section] = [ordered]@{}

    foreach ($Key in $Defaults[$Section].Keys) {
        $Data[$Section][$Key] =
            [bool]$Checks["$Section.$Key"].Checked
    }
}

return $Data

}

$Form = New-Object System.Windows.Forms.Form
$Form.Text = 'Web Sentinel â€” Settings'
$Form.StartPosition = 'CenterScreen'
$Form.ClientSize = New-Object System.Drawing.Size(735, 720)
$Form.MinimumSize = New-Object System.Drawing.Size(750, 759)
$Form.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$Form.AutoScroll = $true

$Intro = New-Object System.Windows.Forms.Label
$Intro.Text = 'Configure protection and logging independently. Master OFF preserves your individual selections.'
$Intro.Location = New-Object System.Drawing.Point(16, 12)
$Intro.Size = New-Object System.Drawing.Size(700, 35)
$Form.Controls.Add($Intro)

$Firewall = New-Object System.Windows.Forms.GroupBox
$Firewall.Text = 'FIREWALL PROTECTION'
$Firewall.Location = New-Object System.Drawing.Point(16, 50)
$Firewall.Size = New-Object System.Drawing.Size(700, 300)
$Form.Controls.Add($Firewall)

Add-CheckBox $Firewall firewall enabled 'MASTER â€” Enable firewall enforcement' 18 25 650
Add-CheckBox $Firewall firewall emojiFiltering 'Emoji filtering' 25 58
Add-CheckBox $Firewall firewall sidebarFiltering 'Sidebar filtering' 355 58
Add-CheckBox $Firewall firewall oobProtection 'OOB bounds and length protection' 25 88
Add-CheckBox $Firewall firewall psnProtection 'PSN and Unicode sanitization' 355 88
Add-CheckBox $Firewall firewall cookieBlocking 'Cookie blocking' 25 118
Add-CheckBox $Firewall firewall networkRequestFirewall 'Network request firewall' 355 118
Add-CheckBox $Firewall firewall adTrackerBlocking 'Ad and tracker blocking' 25 148
Add-CheckBox $Firewall firewall urlFiltering 'URL filtering' 355 148
Add-CheckBox $Firewall firewall suspiciousUnicodeBlocking 'Suspicious Unicode request checks' 25 178 320
Add-CheckBox $Firewall firewall domFiltering 'DOM filtering' 355 178

$FirewallNote = New-Object System.Windows.Forms.Label
$FirewallNote.Text = 'Master OFF must bypass all firewall enforcement. Child settings remain saved.'
$FirewallNote.Location = New-Object System.Drawing.Point(25, 230)
$FirewallNote.Size = New-Object System.Drawing.Size(650, 35)
$Firewall.Controls.Add($FirewallNote)

$Logging = New-Object System.Windows.Forms.GroupBox
$Logging.Text = 'NETWORK LOGGING â€” INDEPENDENT FROM FIREWALL'
$Logging.Location = New-Object System.Drawing.Point(16, 360)
$Logging.Size = New-Object System.Drawing.Size(700, 245)
$Form.Controls.Add($Logging)

Add-CheckBox $Logging logging enabled 'MASTER â€” Enable network logging' 18 25 650
Add-CheckBox $Logging logging dns 'DNS query events' 25 58
Add-CheckBox $Logging logging tcpHandshakes 'TCP handshake metadata' 355 58
Add-CheckBox $Logging logging tlsHandshakes 'TLS handshake metadata' 25 88
Add-CheckBox $Logging logging incomingConnections 'Incoming connection attempts' 355 88
Add-CheckBox $Logging logging proxyActivity 'Proxy request and response events' 25 118 320
Add-CheckBox $Logging logging firewallDecisions 'Firewall allow/block decisions' 355 118
Add-CheckBox $Logging logging cookieEvents 'Cookie policy events (no values)' 25 148 320
Add-CheckBox $Logging logging oobPsnEvents 'OOB and PSN validation events' 355 148
Add-CheckBox $Logging logging extensionDiagnostics 'Extension diagnostics' 25 178

$Save = New-Object System.Windows.Forms.Button
$Save.Text = 'Save Settings'
$Save.Location = New-Object System.Drawing.Point(16, 620)
$Save.Size = New-Object System.Drawing.Size(130, 34)
$Form.Controls.Add($Save)

$DefaultsButton = New-Object System.Windows.Forms.Button
$DefaultsButton.Text = 'Restore Defaults'
$DefaultsButton.Location = New-Object System.Drawing.Point(156, 620)
$DefaultsButton.Size = New-Object System.Drawing.Size(130, 34)
$Form.Controls.Add($DefaultsButton)

$OpenFolder = New-Object System.Windows.Forms.Button
$OpenFolder.Text = 'Open Logs Folder'
$OpenFolder.Location = New-Object System.Drawing.Point(296, 620)
$OpenFolder.Size = New-Object System.Drawing.Size(130, 34)
$Form.Controls.Add($OpenFolder)

$Close = New-Object System.Windows.Forms.Button
$Close.Text = 'Close'
$Close.Location = New-Object System.Drawing.Point(586, 620)
$Close.Size = New-Object System.Drawing.Size(130, 34)
$Form.Controls.Add($Close)

$Status = New-Object System.Windows.Forms.Label
$Status.Text = 'Settings are persisted locally. Enforcement and capture require the next integration step.'
$Status.Location = New-Object System.Drawing.Point(16, 665)
$Status.Size = New-Object System.Drawing.Size(700, 28)
$Form.Controls.Add($Status)

$Save.Add_Click({
try {
Save-Config (Collect-Controls)
$Status.Text = "Settings saved at $(Get-Date -Format 'HH:mm:ss')."
}
catch {
[System.Windows.Forms.MessageBox]::Show(
"Unable to save settings:`r`n$($_.Exception.Message)",
'Web Sentinel Settings',
'OK',
'Error'
) | Out-Null
}
})

$DefaultsButton.Add_Click({
$Answer = [System.Windows.Forms.MessageBox]::Show(
'Restore default selections? Current selections will be overwritten.',
'Restore Defaults',
'YesNo',
'Warning'
)

if ($Answer -ne [System.Windows.Forms.DialogResult]::Yes) {
    return
}

Load-Controls $Defaults

try {
    Save-Config (Collect-Controls)
    $Status.Text = 'Default selections restored and saved.'
}
catch {
    [System.Windows.Forms.MessageBox]::Show(
        "Unable to save defaults:`r`n$($_.Exception.Message)",
        'Web Sentinel Settings',
        'OK',
        'Error'
    ) | Out-Null
}

})

$OpenFolder.Add_Click({
$LogsPath = Join-Path $BasePath 'logs'
if (-not (Test-Path -LiteralPath $LogsPath)) {
New-Item -ItemType Directory -Path $LogsPath -Force | Out-Null
}
Start-Process explorer.exe -ArgumentList "`"$LogsPath`""
})

$Close.Add_Click({ $Form.Close() })

Load-Controls (Read-Config)
[void]$Form.ShowDialog()
'@

Set-Content -LiteralPath $GuiPath -Value $Gui -Encoding UTF8

Write-Host ''
Write-Host 'Web Sentinel settings files created.' -ForegroundColor Green
Write-Host "Settings: $SettingsPath"
Write-Host "GUI:      $GuiPath"
Write-Host ''
Write-Host 'Run the GUI with:'
Write-Host "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$GuiPath`""
Write-Host ''
Write-Warning 'This creates settings and the GUI only. Existing enforcement and packet capture are not wired to these switches yet.'
