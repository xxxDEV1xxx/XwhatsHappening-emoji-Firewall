Set shell = CreateObject("WScript.Shell")
command = """" & "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" & """" & _
          " -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " & _
          """" & "J:\EmojiFirewall\WebSentinelLauncher\WebSentinel-Tray.ps1" & """"
shell.Run command, 0, False
