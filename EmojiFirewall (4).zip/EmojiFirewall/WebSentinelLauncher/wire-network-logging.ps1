# Targeted Web Sentinel network logging wiring. Run elevated in PowerShell.
# Makes timestamped backups and refuses ambiguous receiver edits.
$ErrorActionPreference = 'Stop'
$root = 'J:\EmojiFirewall\BrowserExtension'
$capture = Join-Path $root 'npcap_handshake_capture.py'
$receiver = Join-Path $root 'web_sentinel_log_server.py'
$settings = 'J:\EmojiFirewall\WebSentinelLauncher\settings.json'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
foreach ($path in @($capture, $receiver, $settings)) {
    if (-not (Test-Path -LiteralPath $path)) { throw "Required file not found: $path" }
    Copy-Item -LiteralPath $path -Destination "$path.backup-$stamp" -Force
}

# This patch script expects the replacement capture file beside itself.
$replacement = Join-Path $PSScriptRoot 'npcap_handshake_capture.py'
if (-not (Test-Path -LiteralPath $replacement)) { throw "Put npcap_handshake_capture.py beside this script: $replacement" }
Copy-Item -LiteralPath $replacement -Destination $capture -Force

# Receiver edits are deliberately limited to the two known mapping declarations.
$src = Get-Content -LiteralPath $receiver -Raw
if ($src -notmatch '(?s)ALLOWED_EVENTS\s*=\s*\{[^}]*"tls\.handshake"') {
    $pattern = '(?s)(ALLOWED_EVENTS\s*=\s*\{)(.*?)(\})'
    $m = [regex]::Match($src, $pattern)
    if (-not $m.Success) { throw 'ALLOWED_EVENTS declaration was not recognized. Backups created; inspect receiver manually.' }
    $body = $m.Groups[2].Value
    if ($body -notmatch '"tcp\.handshake"') { throw 'Expected tcp.handshake entry missing in ALLOWED_EVENTS. No receiver edit applied.' }
    $body = $body.TrimEnd() + "`r`n    `"tls.handshake`","
    $src = $src.Substring(0, $m.Groups[1].Index) + $m.Groups[1].Value + $body + $m.Groups[3].Value + $src.Substring($m.Groups[3].Index + $m.Groups[3].Length)
}
if ($src -notmatch '(?s)EVENT_SWITCH\s*=\s*\{[^}]*"tls\.handshake"\s*:') {
    $pattern = '(?s)(EVENT_SWITCH\s*=\s*\{)(.*?)(\})'
    $m = [regex]::Match($src, $pattern)
    if (-not $m.Success) { throw 'EVENT_SWITCH declaration was not recognized. Backups created; inspect receiver manually.' }
    $body = $m.Groups[2].Value
    if ($body -notmatch '"tcp\.handshake"\s*:\s*"tcpHandshakes"') { throw 'Expected tcp.handshake mapping missing in EVENT_SWITCH.' }
    $body = $body.TrimEnd() + "`r`n    `"tls.handshake`": `"tlsHandshakes`","
    $src = $src.Substring(0, $m.Groups[1].Index) + $m.Groups[1].Value + $body + $m.Groups[3].Value + $src.Substring($m.Groups[3].Index + $m.Groups[3].Length)
}
Set-Content -LiteralPath $receiver -Value $src -Encoding UTF8

# Validate settings JSON was preserved as valid JSON; no GUI/settings keys are rewritten.
Get-Content -LiteralPath $settings -Raw | ConvertFrom-Json | Out-Null
& 'C:\Python314\python.exe' -m py_compile $capture
if ($LASTEXITCODE -ne 0) { throw 'Capture script syntax check failed. Restore timestamped backups.' }
Write-Host "Patched capture and receiver. Backups use suffix .backup-$stamp"
Write-Host 'Next: restart the receiver and test the capture process before wiring auto-start into the GUI.'
