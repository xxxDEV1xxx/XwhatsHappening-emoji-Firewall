﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$launcherHome = 'J:\EmojiFirewall\WebSentinelLauncher'
$launcher = Join-Path $launcherHome 'WebSentinel-Toggle.ps1'
$stateFile = Join-Path $launcherHome 'running.json'
$logs = Join-Path $launcherHome 'logs'
$psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'

function Get-SentinelState {
    $result = [ordered]@{
        Mode = 'OFF'
        Proxy = $false
        ExtensionLauncher = $false
    }

    if (!(Test-Path $stateFile)) { return [pscustomobject]$result }

    try {
        $s = Get-Content $stateFile -Raw | ConvertFrom-Json
        $result.Proxy = [bool](Get-Process -Id ([int]$s.ProxyPid) -ErrorAction SilentlyContinue)
        $result.ExtensionLauncher = [bool](Get-Process -Id ([int]$s.WebExtPid) -ErrorAction SilentlyContinue)

        if ($result.Proxy -and $result.ExtensionLauncher) {
            $result.Mode = 'ON'
        } elseif ($result.Proxy -or $result.ExtensionLauncher) {
            $result.Mode = 'PARTIAL'
        } else {
            $result.Mode = 'STALE'
        }
    } catch {
        $result.Mode = 'UNKNOWN'
    }

    return [pscustomobject]$result
}

$menu = New-Object System.Windows.Forms.ContextMenuStrip
$toggleItem = New-Object System.Windows.Forms.ToolStripMenuItem
$statusItem = New-Object System.Windows.Forms.ToolStripMenuItem
$statusItem.Enabled = $false
$menu.Items.Add($toggleItem) | Out-Null
$menu.Items.Add($statusItem) | Out-Null
$openEventLogItem = New-Object System.Windows.Forms.ToolStripMenuItem('Open event log')
$menu.Items.Add($openEventLogItem) | Out-Null
$menu.Items.Add('-') | Out-Null
$exitItem = New-Object System.Windows.Forms.ToolStripMenuItem('Exit tray controller')
$menu.Items.Add($exitItem) | Out-Null

$icon = New-Object System.Windows.Forms.NotifyIcon
$icon.Icon = [System.Drawing.SystemIcons]::Shield
$icon.Text = 'Web Sentinel: checking status'
$icon.ContextMenuStrip = $menu
$icon.Visible = $true

$script:busy = $false
$script:child = $null

function Refresh-Tray {
    $s = Get-SentinelState

    switch ($s.Mode) {
        'ON' {
            $toggleItem.Text = 'Disable Web Sentinel'
            $statusItem.Text = 'Status: ON — proxy and extension launcher running'
            $icon.Text = 'Web Sentinel: ON'
        }
        'PARTIAL' {
            $toggleItem.Text = 'Stop / restart Web Sentinel'
            $statusItem.Text = "Status: PARTIAL — proxy=$($s.Proxy), extension launcher=$($s.ExtensionLauncher)"
            $icon.Text = 'Web Sentinel: PARTIAL'
        }
        'STALE' {
            $toggleItem.Text = 'Reset / start Web Sentinel'
            $statusItem.Text = 'Status: recorded processes are no longer running'
            $icon.Text = 'Web Sentinel: needs restart'
        }
        'UNKNOWN' {
            $toggleItem.Text = 'Check / restart Web Sentinel'
            $statusItem.Text = 'Status: UNKNOWN — inspect launcher logs'
            $icon.Text = 'Web Sentinel: UNKNOWN'
        }
        default {
            $toggleItem.Text = 'Enable Web Sentinel'
            $statusItem.Text = 'Status: OFF'
            $icon.Text = 'Web Sentinel: OFF'
        }
    }

    if ($script:busy) {
        $toggleItem.Enabled = $false
        $statusItem.Text = 'Status: starting or stopping...'
        $icon.Text = 'Web Sentinel: changing state'
    } else {
        $toggleItem.Enabled = $true
    }
}

$toggleItem.Add_Click({
    if ($script:busy) { return }

    $script:busy = $true
    Refresh-Tray

    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $outLog = Join-Path $logs "tray-launch-$stamp.out.log"
    $errLog = Join-Path $logs "tray-launch-$stamp.err.log"

    try {
        $script:child = Start-Process -FilePath $psExe `
            -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$launcher`"") `
            -WorkingDirectory $launcherHome `
            -WindowStyle Hidden `
            -RedirectStandardOutput $outLog `
            -RedirectStandardError $errLog `
            -PassThru
    } catch {
        $script:busy = $false
        [System.Windows.Forms.MessageBox]::Show(
            "Could not run the Web Sentinel launcher.`r`n$_`r`nLogs: $logs",
            'Web Sentinel',
            'OK',
            'Error'
        ) | Out-Null
        Refresh-Tray
    }
})

$openEventLogItem.Add_Click({
    $eventLog = Join-Path $logs 'web-sentinel.jsonl'
    if (Test-Path -LiteralPath $eventLog) {
        Start-Process -FilePath $eventLog
    } else {
        [System.Windows.Forms.MessageBox]::Show(
            "The event log does not exist yet:`r`n$eventLog",
            'Web Sentinel',
            'OK',
            'Information'
        ) | Out-Null
    }
})

$exitItem.Add_Click({
    $icon.Visible = $false
    $timer.Stop()
    $timer.Dispose()
    $menu.Dispose()
    $icon.Dispose()
    [System.Windows.Forms.Application]::Exit()
})

$icon.Add_DoubleClick({
    $toggleItem.PerformClick()
})

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 1500
$timer.Add_Tick({
    if ($script:busy -and $script:child) {
        try {
            $script:child.Refresh()
            if ($script:child.HasExited) {
                $script:busy = $false
                $script:child = $null
                Refresh-Tray
                $s = Get-SentinelState
                if ($s.Mode -eq 'ON') {
                    $icon.ShowBalloonTip(2500, 'Web Sentinel', 'Protection launcher is running.', [System.Windows.Forms.ToolTipIcon]::Info)
                } elseif ($s.Mode -ne 'OFF') {
                    $icon.ShowBalloonTip(3500, 'Web Sentinel', "Current state: $($s.Mode). Check logs if startup failed.", [System.Windows.Forms.ToolTipIcon]::Warning)
                }
            }
        } catch {
            $script:busy = $false
            $script:child = $null
        }
    }
    Refresh-Tray
})
$timer.Start()

Refresh-Tray
[System.Windows.Forms.Application]::Run()

