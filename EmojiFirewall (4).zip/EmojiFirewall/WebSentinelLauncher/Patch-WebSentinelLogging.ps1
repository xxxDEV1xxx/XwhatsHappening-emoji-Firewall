
$ErrorActionPreference = 'Stop'

$HomeDir = 'J:\EmojiFirewall\WebSentinelLauncher'
$ExtDir = 'J:\EmojiFirewall\BrowserExtension'
$TogglePath = Join-Path $HomeDir 'WebSentinel-Toggle.ps1'
$GuardPath = Join-Path $ExtDir 'request-guard.js'
$ReceiverPath = Join-Path $ExtDir 'web_sentinel_log_server.py'

foreach ($path in @($TogglePath, $GuardPath, $ReceiverPath)) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Required source file not found: $path"
    }
}

function Normalize-Newlines([string]$Text) {
    return $Text.Replace("`r`n", "`n").Replace("`r", "`n")
}

function Replace-Once {
    param(
        [string]$Text,
        [string]$Old,
        [string]$New,
        [string]$Label
    )

    $textN = Normalize-Newlines $Text
    $oldN = Normalize-Newlines $Old
    $newN = Normalize-Newlines $New

    $first = $textN.IndexOf($oldN, [StringComparison]::Ordinal)
    if ($first -lt 0) {
        throw "PREFLIGHT FAILED: anchor not found ($Label). No files modified."
    }

    if ($textN.IndexOf(
        $oldN, $first + $oldN.Length, [StringComparison]::Ordinal
    ) -ge 0) {
        throw "PREFLIGHT FAILED: anchor is not unique ($Label). No files modified."
    }

    return $textN.Substring(0, $first) + $newN +
        $textN.Substring($first + $oldN.Length)
}

# Read and normalize all sources. Nothing is written during preflight.
$original = @{
    Guard = [IO.File]::ReadAllText($GuardPath)
    Receiver = [IO.File]::ReadAllText($ReceiverPath)
    Toggle = [IO.File]::ReadAllText($TogglePath)
}

$updated = @{
    Guard = Normalize-Newlines $original.Guard
    Receiver = Normalize-Newlines $original.Receiver
    Toggle = Normalize-Newlines $original.Toggle
}

# 1. Add a best-effort sender to the extension's local logging receiver.
$updated.Guard = Replace-Once $updated.Guard @'
    function loggingOn(key) {
        return runtimeSettings?.logging?.enabled === true &&
               runtimeSettings?.logging?.[key] === true;
    }
'@ @'
    function loggingOn(key) {
        return runtimeSettings?.logging?.enabled === true &&
               runtimeSettings?.logging?.[key] === true;
    }

    const SENTINEL_LOG_URL = "http://127.0.0.1:2222/log";

    function postSentinelLog(event) {
        try {
            const out = { ...event };

            // Do not send query strings or URL fragments to the log.
            if (typeof out.url === "string") {
                try {
                    const u = new URL(out.url);
                    out.url = u.origin + u.pathname;
                } catch (_) {
                    out.url = "";
                }
            }

            fetch(SENTINEL_LOG_URL, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(out),
                cache: "no-store"
            }).catch(() => {});
        } catch (_) {
            // Logging must never interrupt firewall enforcement.
        }
    }
'@ 'Add extension log sender'

# 2. Forward blocked network decisions only when that logging switch is on.
$updated.Guard = Replace-Once $updated.Guard @'
        if (decision.decision === "allow") {
            if (rules?.policy?.logAllowed) console.info(PREFIX, entry);
        } else {
            console.warn(PREFIX, entry);
        }
'@ @'
        if (decision.decision === "allow") {
            if (rules?.policy?.logAllowed) console.info(PREFIX, entry);
        } else {
            if (loggingOn("firewallDecisions")) {
                console.warn(PREFIX, entry);
                postSentinelLog({
                    ...entry,
                    eventType: "firewall.violation"
                });
            }
        }
'@ 'Forward blocked network decisions'

# 3. Log cookie-block metadata only; never log cookie values.
$updated.Guard = Replace-Once $updated.Guard @'
        if (filtered.length !== (details.responseHeaders || []).length) {
          console.warn("[COOKIE_GUARD] Set-Cookie stripped", {
            url: details.url,
            tabId: details.tabId
          });
          return { responseHeaders: filtered };
        }
'@ @'
        if (filtered.length !== (details.responseHeaders || []).length) {
          if (loggingOn("cookieEvents")) {
            postSentinelLog({
              component: "WebSentinelCookie",
              eventType: "cookie.event",
              decision: "block",
              reason: "Set-Cookie response headers stripped",
              url: details.url,
              tabId: details.tabId,
              timestamp: new Date().toISOString()
            });
          }
          return { responseHeaders: filtered };
        }
'@ 'Forward cookie-block metadata'

# 4. Permit cookie.event in the receiver's event allowlist.
$updated.Receiver = Replace-Once $updated.Receiver @'
ALLOWED_EVENTS = {"tcp.handshake", "firewall.violation", "dns.query", "network.inbound", "network.alert"}
'@ @'
ALLOWED_EVENTS = {"tcp.handshake", "firewall.violation", "dns.query", "network.inbound", "network.alert", "cookie.event"}
'@ 'Allow cookie events'

# 5. Apply the cookieEvents settings switch to cookie.event.
$updated.Receiver = Replace-Once $updated.Receiver @'
    "firewall.violation": "firewallDecisions",
'@ @'
    "firewall.violation": "firewallDecisions",
    "cookie.event": "cookieEvents",
'@ 'Map cookie event logging switch'

# 6. Recover and stop the receiver only after verifying its command line.
# This replaces the existing process-stop loop.
$updated.Toggle = Replace-Once $updated.Toggle @'
    foreach ($id in @([int]$s.WebExtPid, [int]$s.ProxyPid, [int]$s.ReceiverPid)) {
        if ($id -gt 0 -and (Get-Process -Id $id -ErrorAction SilentlyContinue)) {
            & taskkill.exe /PID $id /T /F 2>$null | Out-Null
        }
    }
'@ @'
    $receiverStopPid = 0
    $candidatePid = [int]$s.ReceiverPid

    if ($candidatePid -le 0) {
        $listener = Get-NetTCPConnection -LocalPort $receiverPort -State Listen `
            -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($listener) {
            $candidatePid = [int]$listener.OwningProcess
        }
    }

    if ($candidatePid -gt 0) {
        $candidate = Get-CimInstance Win32_Process `
            -Filter "ProcessId = $candidatePid" `
            -ErrorAction SilentlyContinue

        if ($candidate -and $candidate.CommandLine -and
            $candidate.CommandLine.IndexOf(
                $receiverScript,
                [StringComparison]::OrdinalIgnoreCase
            ) -ge 0) {
            $receiverStopPid = $candidatePid
        }
    }

    $stopIds = @(
        [int]$s.WebExtPid
        [int]$s.ProxyPid
        $receiverStopPid
    ) | Where-Object { $_ -gt 0 } | Select-Object -Unique

    foreach ($id in $stopIds) {
        if (Get-Process -Id $id -ErrorAction SilentlyContinue) {
            & taskkill.exe /PID $id /T /F 2>$null | Out-Null
        }
    }
'@ 'Safely recover receiver PID on toggle-off'

# 7. Adopt an existing receiver on port 2222 instead of starting a duplicate.
$updated.Toggle = Replace-Once $updated.Toggle @'
if ($portBusy) {
    Write-Warning "Port $receiverPort already in use; log receiver not started."
} elseif (!$py -or !(Test-Path $receiverScript)) {
'@ @'
if ($portBusy) {
    $ownerPid = [int]($portBusy | Select-Object -First 1).OwningProcess
    $ownerProc = if ($ownerPid -gt 0) {
        Get-CimInstance Win32_Process -Filter "ProcessId = $ownerPid" `
            -ErrorAction SilentlyContinue
    }

    if ($ownerProc -and $ownerProc.CommandLine -and
        $ownerProc.CommandLine.IndexOf(
            $receiverScript,
            [StringComparison]::OrdinalIgnoreCase
        ) -ge 0) {
        $receiverPid = [int]$ownerProc.ProcessId
        Write-Host "Using existing Web Sentinel receiver (PID $receiverPid)."
    } else {
        Write-Warning "Port $receiverPort is occupied by another process; receiver not adopted."
    }
} elseif (!$py -or !(Test-Path $receiverScript)) {
'@ 'Adopt existing receiver at startup'

Write-Host 'All seven exact-anchor checks passed.' -ForegroundColor Green

# Preserve the original newline convention for each file.
$plans = @(
    @{ Key = 'Guard'; Path = $GuardPath },
    @{ Key = 'Receiver'; Path = $ReceiverPath },
    @{ Key = 'Toggle'; Path = $TogglePath }
)

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupDir = Join-Path $HomeDir "backups\logging-$stamp"
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

# Back up all targets before writing any of them.
foreach ($plan in $plans) {
    Copy-Item -LiteralPath $plan.Path -Destination $backupDir
}

$utf8NoBom = [System.Text.UTF8Encoding]::new($false)

foreach ($plan in $plans) {
    $raw = $original[$plan.Key]
    $newline = if ($raw.Contains("`r`n")) { "`r`n" } else { "`n" }
    $output = $updated[$plan.Key].Replace("`n", $newline)

    [System.IO.File]::WriteAllText(
        $plan.Path,
        $output,
        $utf8NoBom
    )
}

Write-Host ''
Write-Host 'Web Sentinel logging patch applied.' -ForegroundColor Green
Write-Host "Backups: $backupDir"
Write-Host 'Next: validate the JavaScript and Python, then test the receiver.'