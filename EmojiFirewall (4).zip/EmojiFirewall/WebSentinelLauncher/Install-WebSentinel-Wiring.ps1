
$ErrorActionPreference = 'Stop'

$HomeDir = 'J:\EmojiFirewall\WebSentinelLauncher'
$ExtDir  = 'J:\EmojiFirewall\BrowserExtension'
$ProxyDir = 'J:\EmojiFirewall\SidebarFirewall'
$SettingsPath = Join-Path $HomeDir 'settings.json'
$Stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$BackupDir = Join-Path $HomeDir "backups\wiring-$Stamp"

$Targets = @(
    (Join-Path $HomeDir 'WebSentinel-Settings.ps1'),
    (Join-Path $ExtDir 'manifest.json'),
    (Join-Path $ExtDir 'content.js'),
    (Join-Path $ExtDir 'request-guard.js'),
    (Join-Path $ExtDir 'sentinel-policy.js'),
    (Join-Path $ProxyDir 'Program.cs'),
    (Join-Path $ProxyDir 'CookiePolicy.cs')
)

foreach ($p in $Targets) {
    if (-not (Test-Path -LiteralPath $p -PathType Leaf)) {
        throw "Required file not found: $p"
    }
}
if (-not (Test-Path -LiteralPath $SettingsPath -PathType Leaf)) {
    throw "Settings file not found: $SettingsPath"
}

# Validate the existing settings before touching anything.
$settings = Get-Content -LiteralPath $SettingsPath -Raw |
    ConvertFrom-Json

foreach ($section in @('firewall', 'logging')) {
    if ($null -eq $settings.$section) {
        throw "Settings are missing the '$section' section."
    }
    if ($null -eq $settings.$section.enabled) {
        throw "Settings are missing '$section.enabled'."
    }
}

# Exact-anchor replacement. Each anchor must occur exactly once.
function Replace-Once {
    param(
        [string]$Text,
        [string]$Old,
        [string]$New,
        [string]$Label
    )
    $first = $Text.IndexOf($Old, [StringComparison]::Ordinal)
    if ($first -lt 0) {
        throw "Preflight failed: anchor not found ($Label). No installation completed."
    }
    if ($Text.IndexOf(
        $Old, $first + $Old.Length, [StringComparison]::Ordinal
    ) -ge 0) {
        throw "Preflight failed: anchor is not unique ($Label)."
    }
    return $Text.Substring(0, $first) + $New +
        $Text.Substring($first + $Old.Length)
}

# Read and validate all source files before making backups or writing.
$gui = Get-Content $Targets[0] -Raw
$manifestText = Get-Content $Targets[1] -Raw
$content = Get-Content $Targets[2] -Raw
$requestGuard = Get-Content $Targets[3] -Raw
$domPolicy = Get-Content $Targets[4] -Raw
$program = Get-Content $Targets[5] -Raw
$cookiePolicy = Get-Content $Targets[6] -Raw

$null = Replace-Once $gui @'
Move-Item -LiteralPath $TemporaryPath `
    -Destination $ConfigPath -Force
'@ @'
Move-Item -LiteralPath $TemporaryPath `
    -Destination $ConfigPath -Force

Copy-Item -LiteralPath $ConfigPath `
    -Destination 'J:\EmojiFirewall\BrowserExtension\sentinel-runtime-settings.json' -Force
'@ 'GUI settings publisher'

$null = Replace-Once $content '"use strict";' '"use strict";' 'content script strict mode'
$null = Replace-Once $requestGuard 'let rules;' 'let rules;' 'request guard rules declaration'
$null = Replace-Once $domPolicy 'function scan(root) {' 'function scan(root) {' 'DOM scan function'
$null = Replace-Once $program 'CookiePolicy.Enforce(uri.Host, e.HttpClient.Response);' 'CookiePolicy.Enforce(uri.Host, e.HttpClient.Response);' 'proxy cookie enforcement'
$null = Replace-Once $cookiePolicy 'public static void Enforce(' 'public static void Enforce(' 'cookie enforcement method'

# Make backups of all files that will be modified.
New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
foreach ($p in $Targets) {
    Copy-Item -LiteralPath $p -Destination $BackupDir
}
Write-Host "Backups created: $BackupDir"

# 1. GUI: publish settings for the extension whenever Save is clicked.
$gui = Replace-Once $gui @'
Move-Item -LiteralPath $TemporaryPath `
    -Destination $ConfigPath -Force
'@ @'
Move-Item -LiteralPath $TemporaryPath `
    -Destination $ConfigPath -Force

Copy-Item -LiteralPath $ConfigPath `
    -Destination 'J:\EmojiFirewall\BrowserExtension\sentinel-runtime-settings.json' -Force
'@ 'GUI settings publisher'

# 2. Create the extension-side settings file and background synchronizer.
Copy-Item -LiteralPath $SettingsPath `
    -Destination (Join-Path $ExtDir 'sentinel-runtime-settings.json') -Force

$bridge = @'
"use strict";

(async function () {
    const KEY = "webSentinelSettings";
    let last = "";

    async function refresh() {
        try {
            const response = await fetch(
                browser.runtime.getURL("sentinel-runtime-settings.json"),
                { cache: "no-store" }
            );
            if (!response.ok) throw new Error("HTTP " + response.status);

            const settings = await response.json();
            if (!settings.firewall || !settings.logging) {
                throw new Error("Invalid settings structure");
            }

            const serialized = JSON.stringify(settings);
            if (serialized !== last) {
                await browser.storage.local.set({ [KEY]: settings });
                last = serialized;
            }
        } catch (e) {
            console.error("[Web Sentinel settings bridge]", String(e));
        }
    }

    await refresh();
    setInterval(refresh, 1000);
})();
'@

Set-Content -LiteralPath (Join-Path $ExtDir 'settings-bridge.js') `
    -Value $bridge -Encoding UTF8

# 3. Add the synchronizer to the existing Firefox background scripts.
$manifest = $manifestText | ConvertFrom-Json
if ($manifest.background.scripts -notcontains 'settings-bridge.js') {
    $manifest.background.scripts += 'settings-bridge.js'
}
$manifest | ConvertTo-Json -Depth 20 |
    Set-Content -LiteralPath (Join-Path $ExtDir 'manifest.json') -Encoding UTF8

# 4. Add dynamic settings access to content.js.
$content = Replace-Once $content @'
    "use strict";
'@ @'
    "use strict";

    let runtimeSettings = null;
    const storageApi = globalThis.browser?.storage ?? globalThis.chrome?.storage;

    function firewallOn(key) {
        return runtimeSettings?.firewall?.enabled === true &&
               runtimeSettings?.firewall?.[key] === true;
    }

    function loggingOn(key) {
        return runtimeSettings?.logging?.enabled === true &&
               runtimeSettings?.logging?.[key] === true;
    }

    if (storageApi?.local) {
        Promise.resolve(storageApi.local.get("webSentinelSettings"))
            .then(result => {
                runtimeSettings = result.webSentinelSettings || null;
            })
            .catch(() => {});

        storageApi.onChanged?.addListener((changes, area) => {
            if (area === "local" && changes.webSentinelSettings) {
                runtimeSettings = changes.webSentinelSettings.newValue || null;
            }
        });
    }
'@ 'content settings helper'

$content = Replace-Once $content @'
      console.warn("[COOKIE_GUARD] document.cookie write blocked", value);
      // write is dropped
'@ @'
      if (!firewallOn("cookieBlocking")) {
        return desc.set.call(this, value);
      }
      if (loggingOn("cookieEvents")) {
        console.warn("[COOKIE_GUARD] document.cookie write blocked");
      }
      // write is dropped; cookie values are never logged
'@ 'document.cookie switch'

$content = Replace-Once $content @'
    function transformText(text) {
        if (!text)
'@ @'
    function transformText(text) {
        if (!firewallOn("emojiFiltering") || !text)
'@ 'emoji filtering switch'

$content = Replace-Once $content @'
function neutralizeSvgTree(root) {
    if (!(root instanceof Node))
'@ @'
function neutralizeSvgTree(root) {
    if (!firewallOn("emojiFiltering") || !(root instanceof Node))
'@ 'SVG filtering switch'

$content = Replace-Once $content @'
    function removeWhatsHappening() {
        if (location.hostname !== "x.com" &&
'@ @'
    function removeWhatsHappening() {
        if (!firewallOn("sidebarFiltering")) return;

        if (location.hostname !== "x.com" &&
'@ 'sidebar filtering switch'

$content = Replace-Once $content @'
        function inspectField(event) {
            const el = event.target;
'@ @'
        function inspectField(event) {
            if (!firewallOn("psnProtection")) return;
            const el = event.target;
'@ 'PSN input inspection switch'

$content = Replace-Once $content @'
        function enforceOptInByteLimit(event) {
            const form = event.target;
'@ @'
        function enforceOptInByteLimit(event) {
            if (!firewallOn("oobProtection")) return;
            const form = event.target;
'@ 'OOB byte limit switch'

$content = Replace-Once $content @'
        document.addEventListener("submit", function blockSuspiciousSubmission(event) {
            const form = event.target;
'@ @'
        document.addEventListener("submit", function blockSuspiciousSubmission(event) {
            if (!firewallOn("psnProtection")) return;
            const form = event.target;
'@ 'PSN submission switch'

# 5. Gate DOM selector enforcement dynamically.
$domPolicy = Replace-Once $domPolicy @'
    const PREFIX = "[Web Sentinel]";
'@ @'
    const PREFIX = "[Web Sentinel]";
    let runtimeSettings = null;
    const settingsStorage = globalThis.browser?.storage ?? globalThis.chrome?.storage;

    function domFilteringOn() {
        return runtimeSettings?.firewall?.enabled === true &&
               runtimeSettings?.firewall?.domFiltering === true;
    }

    if (settingsStorage?.local) {
        Promise.resolve(settingsStorage.local.get("webSentinelSettings"))
            .then(result => {
                runtimeSettings = result.webSentinelSettings || null;
            }).catch(() => {});
        settingsStorage.onChanged?.addListener((changes, area) => {
            if (area === "local" && changes.webSentinelSettings) {
                runtimeSettings = changes.webSentinelSettings.newValue || null;
            }
        });
    }
'@ 'DOM settings helper'

$domPolicy = Replace-Once $domPolicy @'
    function scan(root) {
        if (!configLoaded || !root)
'@ @'
    function scan(root) {
        if (!domFilteringOn() || !configLoaded || !root)
'@ 'DOM filtering switch'

# 6. Request guard: cache settings and gate network/cookie interception.
$requestGuard = Replace-Once $requestGuard @'
    let rules;
'@ @'
    let rules;
    let runtimeSettings = null;

    function firewallOn(key) {
        return runtimeSettings?.firewall?.enabled === true &&
               runtimeSettings?.firewall?.[key] === true;
    }

    function loggingOn(key) {
        return runtimeSettings?.logging?.enabled === true &&
               runtimeSettings?.logging?.[key] === true;
    }

    browser.storage.local.get("webSentinelSettings").then(result => {
        runtimeSettings = result.webSentinelSettings || null;
    }).catch(() => {});

    browser.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && changes.webSentinelSettings) {
            runtimeSettings = changes.webSentinelSettings.newValue || null;
        }
    });
'@ 'request guard settings helper'

$requestGuard = Replace-Once $requestGuard @'
            function (details) {
                try {
                    const decision = globalThis.WebSentinelPolicy.evaluate({
'@ @'
            function (details) {
                try {
                    if (!runtimeSettings?.firewall?.enabled) return {};

                    const policyRules = {
                        ...rules,
                        domains: firewallOn("networkRequestFirewall")
                            ? rules.domains
                            : { block: [], allow: [] },
                        adsAndTrackers: {
                            ...rules.adsAndTrackers,
                            enabled: firewallOn("adTrackerBlocking") &&
                                     rules.adsAndTrackers?.enabled !== false
                        },
                        urls: firewallOn("urlFiltering")
                            ? rules.urls
                            : { blockPatterns: [], allowPatterns: [] },
                        headers: firewallOn("networkRequestFirewall")
                            ? rules.headers
                            : { required: [], blockedNames: [], maxCount: 100000, maxValueLength: 1000000 },
                        contentTypes: firewallOn("networkRequestFirewall")
                            ? rules.contentTypes
                            : { block: [] },
                        limits: firewallOn("networkRequestFirewall")
                            ? rules.limits
                            : { maxUrlLength: 1000000, maxHeaderCount: 1000000 }
                    };

                    const decision = globalThis.WebSentinelPolicy.evaluate({
'@ 'network request feature gates'

$requestGuard = Replace-Once $requestGuard @'
                    }, rules);

                    if (decision.decision === "block" ||
'@ @'
                    }, policyRules);

                    if (decision.decision === "block" ||
'@ 'effective policy argument'

$requestGuard = Replace-Once $requestGuard @'
                    if (inspectBody(details.requestBody)) {
'@ @'
                    if (firewallOn("suspiciousUnicodeBlocking") &&
                        inspectBody(details.requestBody)) {
'@ 'request Unicode switch'

$requestGuard = Replace-Once $requestGuard @'
    async function isDomainAllowed(hostname) {
'@ @'
    async function isDomainAllowed(hostname) {
      if (!firewallOn("cookieBlocking")) return true;
'@ 'cookie response switch'

$requestGuard = Replace-Once $requestGuard @'
    async (details) => {
      try {
        const url = new URL(details.url);
'@ @'
    async (details) => {
      try {
        if (!firewallOn("cookieBlocking")) return;
        const url = new URL(details.url);
'@ 'cookie response listener switch'

# 7. Add a shared settings reader for the C# proxy.
$settingsClass = @'
using System.Text.Json.Nodes;

internal static class FirewallSettings
{
    private const string ConfigPath =
        @"J:\EmojiFirewall\WebSentinelLauncher\settings.json";

    public static bool FirewallEnabled(string key) =>
        ReadBool("firewall", "enabled") && ReadBool("firewall", key);

    public static bool LoggingEnabled(string key) =>
        ReadBool("logging", "enabled") && ReadBool("logging", key);

    private static bool ReadBool(string section, string key)
    {
        try
        {
            if (!File.Exists(ConfigPath)) return false;
            var root = JsonNode.Parse(File.ReadAllText(ConfigPath));
            return root?[section]?[key]?.GetValue<bool>() == true;
        }
        catch
        {
            return false;
        }
    }
}
'@

Set-Content -LiteralPath (Join-Path $ProxyDir 'FirewallSettings.cs') `
    -Value $settingsClass -Encoding UTF8

$program = Replace-Once $program @'
        if (uri is not null &&
            (uri.Host.Equals("x.com", StringComparison.OrdinalIgnoreCase) ||
'@ @'
        if (FirewallSettings.LoggingEnabled("proxyActivity") &&
            uri is not null &&
            (uri.Host.Equals("x.com", StringComparison.OrdinalIgnoreCase) ||
'@ 'proxy activity logging gate'

$program = Replace-Once $program @'
            if (uri is null ||
                !string.Equals(uri.Host, "x.com",
'@ @'
            if (!FirewallSettings.FirewallEnabled("sidebarFiltering") ||
                uri is null ||
                !string.Equals(uri.Host, "x.com",
'@ 'proxy sidebar switch'

# 8. Gate C# cookie enforcement and cookie event logs.
$cookiePolicy = Replace-Once $cookiePolicy @'
    {
        var cookies = response.Headers.GetHeaders("Set-Cookie")?.ToList();
'@ @'
    {
        if (!FirewallSettings.FirewallEnabled("cookieBlocking")) return;

        var cookies = response.Headers.GetHeaders("Set-Cookie")?.ToList();
'@ 'proxy cookie enforcement switch'

$cookiePolicy = Replace-Once $cookiePolicy @'
    {
        var hdr = request.Headers.GetFirstHeader("Cookie");
'@ @'
    {
        if (!FirewallSettings.LoggingEnabled("cookieEvents")) return;

        var hdr = request.Headers.GetFirstHeader("Cookie");
'@ 'proxy request cookie log switch'

$cookiePolicy = $cookiePolicy.Replace(
    'Console.WriteLine(',
    'if (FirewallSettings.LoggingEnabled("cookieEvents")) Console.WriteLine('
)

# Only write the source files after all anchor checks above succeeded.
Set-Content -LiteralPath $Targets[0] -Value $gui -Encoding UTF8
Set-Content -LiteralPath $Targets[2] -Value $content -Encoding UTF8
Set-Content -LiteralPath $Targets[3] -Value $requestGuard -Encoding UTF8
Set-Content -LiteralPath $Targets[4] -Value $domPolicy -Encoding UTF8
Set-Content -LiteralPath $Targets[5] -Value $program -Encoding UTF8
Set-Content -LiteralPath $Targets[6] -Value $cookiePolicy -Encoding UTF8

Write-Host ''
Write-Host 'Web Sentinel settings wiring installed.' -ForegroundColor Green
Write-Host "Backups: $BackupDir"
Write-Host 'Next: rebuild SidebarFirewall and restart Web Sentinel / Firefox.'