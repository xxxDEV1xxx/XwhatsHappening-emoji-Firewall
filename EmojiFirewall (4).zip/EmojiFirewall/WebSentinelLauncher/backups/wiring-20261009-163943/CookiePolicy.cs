static class CookiePolicy
{
    private static readonly object Gate = new();
    private static readonly string ListPath =
        Path.Combine(AppContext.BaseDirectory, "approved-hosts.txt");
    private static HashSet<string> _approved =
        new(StringComparer.OrdinalIgnoreCase);
    private static DateTime _stamp = DateTime.MinValue;

    private static bool IsApproved(string host)
    {
        lock (Gate)
        {
            DateTime stamp = File.Exists(ListPath)
                ? File.GetLastWriteTimeUtc(ListPath)
                : DateTime.MinValue;

            if (stamp != _stamp)
            {
                var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                if (stamp != DateTime.MinValue)
                {
                    foreach (string raw in File.ReadAllLines(ListPath))
                    {
                        string line = raw.Trim();
                        if (line.Length == 0 || line.StartsWith('#')) continue;
                        set.Add(line.TrimStart('.'));
                    }
                }
                _approved = set;
                _stamp = stamp;
            }

            foreach (string entry in _approved)
            {
                if (host.Equals(entry, StringComparison.OrdinalIgnoreCase) ||
                    host.EndsWith("." + entry, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }
    }

    public static void Enforce(
        string host, Titanium.Web.Proxy.Http.Response response)
    {
        var cookies = response.Headers.GetHeaders("Set-Cookie")?.ToList();
        if (cookies is null || cookies.Count == 0) return;

        bool approved = IsApproved(host);

        foreach (var h in cookies)
        {
            string[] parts = (h.Value ?? "").Split(';');
            string name = parts[0].Split('=')[0].Trim();
            string attrs = string.Join(",", parts.Skip(1)
                .Select(p => p.Split('=')[0].Trim())
                .Where(p => p.Length > 0));

            Console.WriteLine(
                $"{DateTime.Now:T} SET-COOKIE {(approved ? "ALLOW" : "DENY ")} " +
                $"host={host} name={name} attrs=[{attrs}]");
        }

        if (!approved)
            response.Headers.RemoveHeader("Set-Cookie");
    }

    public static void LogRequestCookies(
        string host, Titanium.Web.Proxy.Http.Request request)
    {
        var hdr = request.Headers.GetFirstHeader("Cookie");
        if (hdr is null) return;

        string names = string.Join(",", (hdr.Value ?? "").Split(';')
            .Select(p => p.Split('=')[0].Trim())
            .Where(p => p.Length > 0));

        Console.WriteLine(
            $"{DateTime.Now:T} COOKIE-REQ host={host} names=[{names}]");
    }
}