﻿(() => {
    "use strict";
// Optional: block document.cookie writes
(function blockDocumentCookie() {
  const desc = Object.getOwnPropertyDescriptor(Document.prototype, "cookie") ||
               Object.getOwnPropertyDescriptor(HTMLDocument.prototype, "cookie");
  if (!desc) return;

  Object.defineProperty(document, "cookie", {
    configurable: true,
    enumerable: true,
    get() { return desc.get.call(this); },
    set(value) {
      console.warn("[COOKIE_GUARD] document.cookie write blocked", value);
      // write is dropped
    }
  });
})();
    function diagnostic(message) {
        try {
            document.documentElement.dataset.emojiFirewall =
                message;
        }
        catch {}

        try {
            console.log(
                "[Emoji Firewall]",
                message
            );
        }
        catch {}
    }

    diagnostic("LOADED");

    const runtime =
        globalThis.browser?.runtime ??
        globalThis.chrome?.runtime;

    if (!runtime)
        return;

    /*
     * Emoji Firewall
     *
     * Catalog:
     *   4,887 Unicode 15.0 entries
     *
     * Matching:
     *   UTF-16 trie
     *   longest registered sequence wins
     *
     * DOM:
     *   incremental MutationObserver processing
     */

    const root = {
        next: new Map(),
        entry: null
    };

    let catalogLoaded = false;
    let observerInstalled = false;

    function entryPriority(entry) {
        if (
            entry.type ===
            "RGI_Emoji_ZWJ_Sequence"
        )
            return 50;

        if (
            entry.type ===
            "Emoji_Keycap_Sequence" ||
            entry.type ===
            "RGI_Emoji_Flag_Sequence" ||
            entry.type ===
            "RGI_Emoji_Tag_Sequence" ||
            entry.type ===
            "RGI_Emoji_Modifier_Sequence" ||
            entry.type ===
            "Basic_Emoji"
        )
            return 40;

        if (entry.status === "fully-qualified")
            return 30;

        if (entry.status === "minimally-qualified")
            return 20;

        if (entry.status === "unqualified")
            return 10;

        if (entry.status === "component")
            return 5;

        return 0;
    }

    function addSequence(sequence, entry) {
        let node = root;

        for (let i = 0; i < sequence.length; i++) {
            const unit =
                sequence.charCodeAt(i);

            let next =
                node.next.get(unit);

            if (!next) {
                next = {
                    next: new Map(),
                    entry: null
                };

                node.next.set(unit, next);
            }

            node = next;
        }

        /*
         * Duplicate Unicode sequences can occur in the
         * source catalog with different classifications.
         * Keep the highest-priority semantic entry.
         */
        if (
            !node.entry ||
            entryPriority(entry) > entryPriority(node.entry)
        ) {
            node.entry = entry;
        }
    }

    function matchAt(text, start) {
        let node = root;
        let position = start;
        let best = null;

        while (position < text.length) {
            const unit =
                text.charCodeAt(position);

            const next =
                node.next.get(unit);

            if (!next)
                break;

            node = next;
            position++;

            if (node.entry) {
                best = {
                    entry: node.entry,
                    end: position
                };
            }
        }

        return best;
    }

    function isEmojiLike(codePoint) {
        return (
            (codePoint >= 0x1F000 &&
             codePoint <= 0x1FAFF) ||
            (codePoint >= 0x2600 &&
             codePoint <= 0x27BF) ||
            (codePoint >= 0x2300 &&
             codePoint <= 0x23FF) ||
            (codePoint >= 0x2B00 &&
             codePoint <= 0x2BFF) ||
            (codePoint >= 0x1F1E6 &&
             codePoint <= 0x1F1FF) ||
            codePoint === 0x20E3 ||
            codePoint === 0xFE0F ||
            codePoint === 0x200D
        );
    }

    function transformText(text) {
        if (!text)
            return text;

        let output = null;
        let lastCopy = 0;
        let position = 0;

        while (position < text.length) {
            const match =
                matchAt(text, position);

            if (match) {
                if (output === null)
                    output = [];

                output.push(
                    text.slice(
                        lastCopy,
                        position
                    )
                );

                output.push("[");
                output.push(match.entry.name);
                output.push("]");

                position = match.end;
                lastCopy = position;

                continue;
            }

            const codePoint =
                text.codePointAt(position);

            const width =
                codePoint > 0xFFFF ? 2 : 1;

            if (isEmojiLike(codePoint)) {
                if (output === null)
                    output = [];

                output.push(
                    text.slice(
                        lastCopy,
                        position
                    )
                );

                output.push(
                    "[UNRECOGNIZED EMOJI]"
                );

                position += width;
                lastCopy = position;

                continue;
            }

            position += width;
        }

        if (output === null)
            return text;

        output.push(
            text.slice(lastCopy)
        );

        return output.join("");
    }

    const SVG_REPLACEMENT =
    "data:image/svg+xml;charset=utf-8," +
    encodeURIComponent(
        '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16">' +
        '<text x="1" y="13" font-size="14">.</text>' +
        '</svg>'
    );

function neutralizeSvgElement(el) {
    if (!(el instanceof Element))
        return;

    const tag = el.tagName.toLowerCase();

    if (tag === "img") {
        const src = el.getAttribute("src") || "";

        if (/\.svg(?:[?#]|$)/i.test(src)) {
            if (el.dataset.emojiFirewallSvg === "1")
                return;

            el.dataset.emojiFirewallSvg = "1";
            el.dataset.emojiFirewallOriginalSrc = src;
            el.setAttribute("src", SVG_REPLACEMENT);
            return;
        }
    }

    if (tag === "svg") {
        if (el.dataset.emojiFirewallSvg === "1")
            return;

        el.dataset.emojiFirewallSvg = "1";
        el.replaceChildren();

        const text = document.createElementNS(
            "http://www.w3.org/2000/svg",
            "text"
        );

        text.setAttribute("x", "1");
        text.setAttribute("y", "13");
        text.setAttribute("font-size", "14");
        text.textContent = ".";

        el.appendChild(text);
    }
}

function neutralizeSvgTree(root) {
    if (!(root instanceof Node))
        return;

    if (root.nodeType === Node.ELEMENT_NODE) {
        neutralizeSvgElement(root);

        if (root.querySelectorAll) {
            root.querySelectorAll("img,svg").forEach(
                neutralizeSvgElement
            );
        }
    }
}
    function removeWhatsHappening() {
        if (location.hostname !== "x.com" &&
            location.hostname !== "www.x.com") {
            return;
        }

        const headings = document.querySelectorAll(
            '[data-testid="trend"], h1, h2, h3, [role="heading"]'
        );

        for (const heading of headings) {
            if (heading.textContent.trim() !== "What’s happening" &&
                heading.textContent.trim() !== "What's happening") {
                continue;
            }

            let candidate = heading;

            for (let depth = 0; depth < 7 && candidate.parentElement; depth++) {
                candidate = candidate.parentElement;

                const text = candidate.innerText || "";

                if (
                    text.includes("What’s happening") ||
                    text.includes("What's happening")
                ) {
                    const rect = candidate.getBoundingClientRect();

                    if (rect.width > 150 && rect.height > 80) {
                        candidate.remove();
                        break;
                    }
                }
            }
        }
    }
function shouldSkip(node) {
        const parent =
            node.parentElement;

        if (!parent)
            return false;

        return !!parent.closest(
            "script,style,noscript,input,textarea,select,option,[contenteditable='true']"
        );
    }

    function processTextNode(node) {
        if (
            !node ||
            !node.nodeValue ||
            shouldSkip(node)
        )
            return;

        const original =
            node.nodeValue;

        const transformed =
            transformText(original);

        if (transformed === original)
            return;

        node.nodeValue = transformed;
    }

    function scanElement(element) {
        if (!element)
            return;

        if (
            element.nodeType ===
            Node.TEXT_NODE
        ) {
            processTextNode(element);
            return;
        }

        const walker =
            document.createTreeWalker(
                element,
                NodeFilter.SHOW_TEXT
            );

        let node;

        while (
            (node = walker.nextNode())
        ) {
            processTextNode(node);
        }
    }

    function installObserver() {
        if (observerInstalled)
            return;

        observerInstalled = true;

        const observer =
            new MutationObserver(
                mutations => {
                    for (const mutation of mutations) {
                        if (
                            mutation.type ===
                            "childList"
                        ) {
                            for (
                                const node
                                of mutation.addedNodes
                            ) {
                                if (
                                    node.nodeType ===
                                    Node.TEXT_NODE
                                ) {
                                    processTextNode(
                                        node
                                    );
                                }
                                else if (
                                    node.nodeType ===
                                    Node.ELEMENT_NODE
                                ) {
                                    neutralizeSvgTree(node);
                                    scanElement(node);
                                }
                            }
                        }
                        else if (
                            mutation.type ===
                            "characterData"
                        ) {
                            processTextNode(
                                mutation.target
                            );
                        }
                    }

                    removeWhatsHappening();
                }
            );

        observer.observe(
            document.documentElement,
            {
                subtree: true,
                childList: true,
                characterData: true
            }
        );
    }

    async function loadCatalog() {
        diagnostic("LOADING_CATALOG");

        const url =
            runtime.getURL("catalog.json");

        const response =
            await fetch(url);

        if (!response.ok) {
            throw new Error(
                `Emoji catalog HTTP ${response.status}`
            );
        }

        const data =
            await response.json();

        if (!Array.isArray(data.entries)) {
            throw new Error(
                "Emoji catalog entries missing."
            );
        }

        for (const entry of data.entries) {
            addSequence(
                entry.sequence,
                entry
            );
        }

        if (data.entries.length !== 4887) {
            console.warn(
                "[Emoji Firewall] expected 4887 catalog entries; received",
                data.entries.length
            );
        }

        catalogLoaded = true;

        diagnostic("CATALOG_LOADED_" + data.entries.length);

        console.log(
            "[Emoji Firewall] catalog loaded:",
            data.entries.length
        );
    }

    function installOobPsnHooks() {
        if (globalThis.__emojiFirewallOobPsnHooksInstalled)
            return;

        const policy = globalThis.PSNPolicy;
        const oob = globalThis.OOBGuard;

        if (!policy || !oob) {
            console.warn("[OOB_PSN] Policy API unavailable.");
            return;
        }

        globalThis.__emojiFirewallOobPsnHooksInstalled = true;

        const lastReported = new WeakMap();
        const suspiciousRE =
            /[\u202a-\u202e\u2066-\u2069\u200b-\u200d\ufeff\u0430\u0435\u043e\u0440\u0441\u0445\u0438\u0439\u043a\u043c\u043d\u0440\u0442\u0432]/;

        function isPasswordField(el) {
            return el instanceof HTMLInputElement &&
                el.type.toLowerCase() === "password";
        }

        function readText(el) {
            if (el instanceof HTMLInputElement ||
                el instanceof HTMLTextAreaElement) {
                return el.value;
            }

            if (el.isContentEditable)
                return el.textContent || "";

            return null;
        }

        function inspectField(event) {
            const el = event.target;

            if (!(el instanceof Element) ||
                isPasswordField(el)) {
                return;
            }

            const value = readText(el);
            if (typeof value !== "string" || !value ||
                !suspiciousRE.test(value)) {
                return;
            }

            if (lastReported.get(el) === value)
                return;

            lastReported.set(el, value);

            // Detection and logging only. Do not rewrite user input.
            policy.strip(value);
        }

        function enforceOptInByteLimit(event) {
            const form = event.target;
            if (!(form instanceof HTMLFormElement))
                return;

            for (const el of form.elements) {
                if (!(el instanceof HTMLInputElement ||
                      el instanceof HTMLTextAreaElement ||
                      el instanceof HTMLSelectElement)) {
                    continue;
                }

                if (isPasswordField(el) || el.disabled)
                    continue;

                const rawLimit =
                    el.getAttribute("data-oob-max-bytes") ??
                    form.getAttribute("data-oob-max-bytes");

                if (rawLimit === null)
                    continue;

                if (!/^\d+$/.test(rawLimit)) {
                    console.warn(
                        "[OOB_GUARD] Invalid data-oob-max-bytes configuration."
                    );
                    continue;
                }

                const limit = Number(rawLimit);
                if (!Number.isSafeInteger(limit))
                    continue;

                const value = el.value;
                if (typeof value !== "string")
                    continue;

                const size = oob.bytes(value);

                if (size > limit) {
                    event.preventDefault();
                    event.stopImmediatePropagation();

                    console.warn("[OOB_GUARD] Form submission blocked:", {
                        field: el.name || el.id || el.tagName,
                        actualBytes: size,
                        maximumBytes: limit
                    });

                    if (typeof el.setCustomValidity === "function") {
                        el.setCustomValidity(
                            `This field exceeds its ${limit}-byte limit.`
                        );
                        el.reportValidity();
                        el.addEventListener("input", () => {
                            el.setCustomValidity("");
                        }, { once: true });
                    }

                    return;
                }
            }
        }

        document.addEventListener("input", inspectField, true);
        document.addEventListener("change", inspectField, true);
        document.addEventListener("submit", enforceOptInByteLimit, true);
        document.addEventListener("submit", function blockSuspiciousSubmission(event) {
            const form = event.target;
            if (!(form instanceof HTMLFormElement)) return;

            const bidiOrInvisible = /[\u202a-\u202e\u2066-\u2069\u200b-\u200d\ufeff]/;

            for (const el of form.elements) {
                if (!(el instanceof HTMLInputElement ||
                      el instanceof HTMLTextAreaElement ||
                      el instanceof HTMLSelectElement)) continue;
                if (el.disabled || isPasswordField(el)) continue;

                const value = el.value;
                if (typeof value !== "string" || !bidiOrInvisible.test(value)) continue;

                event.preventDefault();
                event.stopImmediatePropagation();

                console.warn("[PSN_BLOCKED] Form submission sent to local blackhole decision.", {
                    field: el.name || el.id || el.tagName,
                    reason: "Bidi or zero-width control character",
                    action: form.action
                });
                return;
            }
        }, true);

        console.info("[OOB_PSN] DOM hooks installed.");
    }
    async function start() {
        try {
            /*
             * document_start may execute before <html> or <body>
             * exists. Do not terminate the firewall in that state.
             *
             * Install the earliest available DOM bootstrap first,
             * then load the Unicode catalog.
             */
            const armObserver = () => {
                if (document.documentElement) {
                    installObserver();
                    return true;
                }

                return false;
            };

            if (!armObserver()) {
                const bootstrapObserver =
                    new MutationObserver(() => {
                        if (armObserver()) {
                            bootstrapObserver.disconnect();
                        }
                    });

                bootstrapObserver.observe(
                    document,
                    {
                        childList: true
                    }
                );
            }

            /*
             * Load and build the semantic trie.
             *
             * The observer is already armed, so DOM mutations
             * occurring while the catalog is loading are captured.
             */
            await loadCatalog();

            /*
             * The catalog may have loaded before <body> exists.
             * Wait for the document root rather than returning.
             */
            const scanWhenReady = () => {
                if (!document.body)
                    return false;

                neutralizeSvgTree(document.body);

                scanElement(
                    document.body
                );

                removeWhatsHappening();

                diagnostic("ACTIVE");

                return true;
            };

            if (!scanWhenReady()) {
                const bodyObserver =
                    new MutationObserver(() => {
                        if (scanWhenReady()) {
                            bodyObserver.disconnect();
                        }
                    });

                bodyObserver.observe(
                    document.documentElement ||
                    document,
                    {
                        childList: true,
                        subtree: true
                    }
                );
            }
        }
        catch (error) {
            console.error(
                "[Emoji Firewall] FAILED:",
                error
            );

            diagnostic("FAILED");
        }
    }

    installOobPsnHooks();

    start();
})();












