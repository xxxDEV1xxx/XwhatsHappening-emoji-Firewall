"use strict";

(async function () {
    const PREFIX = "[Web Sentinel]";
    let rules;
    let runtimeSettings = null;

    function firewallOn(key) {
        if (runtimeSettings === null) return true;
        return runtimeSettings.firewall?.enabled === true &&
               runtimeSettings.firewall?.[key] === true;
    }

    function loggingOn(key) {
        return runtimeSettings?.logging?.enabled === true &&
               runtimeSettings?.logging?.[key] === true;
    }

    browser.storage.local.get("webSentinelSettings").then(result => {
        runtimeSettings = result.webSentinelSettings || null;
    }).catch(() => {});

    browser.storage.onChanged.addListener((changes, area) => {
        if (area === "local" && changes.webSentinelSettings) {
            runtimeSettings = changes.webSentinelSettings.newValue || null;
        }
    });

    function log(decision, details) {
        const entry = {
            component: "WebSentinelNetwork",
            decision: decision.decision,
            reason: decision.reason,
            ruleId: decision.ruleId,
            url: String(details.url || "").slice(0, 2048),
            method: String(details.method || "").slice(0, 16),
            requestType: String(details.type || ""),
            timestamp: new Date().toISOString()
        };

        if (decision.decision === "allow") {
            if (rules?.policy?.logAllowed) console.info(PREFIX, entry);
        } else {
            console.warn(PREFIX, entry);
        }
    }

    function inspectBody(body) {
        if (!body) return false;

        const suspicious =
            /[\u202A-\u202E\u2066-\u2069\u200B-\u200D\uFEFF]/;

        function hasSuspicious(value) {
            if (typeof value !== "string") return false;
            if (suspicious.test(value)) return true;
            if (/\\u(?:202[a-e]|206[6-9]|200[b-d]|feff)/i.test(value)) {
                return true;
            }
            try {
                return suspicious.test(decodeURIComponent(value));
            } catch (_) {
                return false;
            }
        }

        if (body.formData) {
            for (const values of Object.values(body.formData)) {
                for (const value of values || []) {
                    if (hasSuspicious(value)) return true;
                }
            }
        }

        if (body.raw) {
            for (const part of body.raw) {
                if (!part.bytes) continue;
                try {
                    const bytes = new Uint8Array(part.bytes);
                    if (bytes.byteLength > 1024 * 1024) continue;
                    if (hasSuspicious(new TextDecoder("utf-8").decode(bytes))) {
                        return true;
                    }
                } catch (_) {}
            }
        }
        return false;
    }

    try {
        const response = await fetch(
            browser.runtime.getURL("sentinel-firewall-rules.json")
        );
        if (!response.ok) throw new Error("Rules fetch failed: " + response.status);
        rules = await response.json();

        if (rules.schemaVersion !== 1) {
            throw new Error("Unsupported rules schema");
        }

        if (!globalThis.WebSentinelPolicy) {
            throw new Error("Policy engine failed to load");
        }

        browser.webRequest.onBeforeRequest.addListener(
            function (details) {
                try {
                    if (runtimeSettings !== null &&
                        runtimeSettings.firewall?.enabled !== true) return {};

                    const policyRules = {
                        ...rules,
                        domains: firewallOn("networkRequestFirewall")
                            ? rules.domains
                            : { block: [], allow: [] },
                        adsAndTrackers: {
                            ...rules.adsAndTrackers,
                            enabled: firewallOn("adTrackerBlocking") &&
                                     rules.adsAndTrackers?.enabled !== false
                        },
                        urls: firewallOn("urlFiltering")
                            ? rules.urls
                            : { blockPatterns: [], allowPatterns: [] },
                        headers: firewallOn("networkRequestFirewall")
                            ? rules.headers
                            : { required: [], blockedNames: [], maxCount: 100000, maxValueLength: 1000000 },
                        contentTypes: firewallOn("networkRequestFirewall")
                            ? rules.contentTypes
                            : { block: [] },
                        limits: firewallOn("networkRequestFirewall")
                            ? rules.limits
                            : { maxUrlLength: 1000000, maxHeaderCount: 1000000 }
                    };

                    const decision = globalThis.WebSentinelPolicy.evaluate({
                        url: details.url,
                        method: details.method,
                        type: details.type,
                        headers: [],
                        contentType: ""
                    }, policyRules);

                    if (decision.decision === "block" ||
                        decision.decision === "reject") {
                        log(decision, details);
                        return { cancel: true };
                    }

                    if (decision.decision === "quarantine") {
                        log(decision, details);
                        // Fail closed for an explicit quarantine decision.
                        return { cancel: true };
                    }

                    if (firewallOn("suspiciousUnicodeBlocking") &&
                        inspectBody(details.requestBody)) {
                        const bodyDecision = {
                            decision: "block",
                            reason: "Request body contains bidi or zero-width controls",
                            ruleId: "unicode.request-body"
                        };
                        log(bodyDecision, details);
                        return { cancel: true };
                    }

                    log(decision, details);
                    return {};
                } catch (error) {
                    const failure = {
                        decision: "quarantine",
                        reason: "Inspection exception: " + String(error?.message || error),
                        ruleId: "engine.exception"
                    };
                    log(failure, details);
                    return { cancel: true };
                }
            },
            { urls: ["http://*/*", "https://*/*"] },
            ["blocking", "requestBody"]
        );

        console.info(PREFIX, "Network request guard registered.");
    } catch (error) {
        console.error(PREFIX, "Network guard startup failed; interceptor not active.", error);
    }
})();

// ---------------------------------------------------------------------------
// Cookie enforcement – deny-by-default
// ---------------------------------------------------------------------------
(function setupCookieGuard() {
  if (typeof browser === "undefined" || !browser.webRequest) return;

  async function isDomainAllowed(hostname) {
      if (!firewallOn("cookieBlocking")) return true;
    try {
      if (globalThis.EmojiFirewallCookiePolicy?.isAllowed) {
        return await globalThis.EmojiFirewallCookiePolicy.isAllowed(hostname);
      }
      const result = await browser.storage.local.get("emojiFirewallCookiePolicy");
      const policy = {
        mode: "deny-by-default",
        allowedDomains: [],
        ...(result.emojiFirewallCookiePolicy || {})
      };
      if (policy.mode !== "deny-by-default") return true;
      const host = hostname.toLowerCase().replace(/^\./, "");
      return policy.allowedDomains.some(d =>
        host === d || host.endsWith("." + d)
      );
    } catch (e) {
      console.warn("[COOKIE_GUARD] policy lookup failed, failing closed", e);
      return false;
    }
  }

  browser.webRequest.onHeadersReceived.addListener(
    async (details) => {
      try {
        if (!firewallOn("cookieBlocking")) return;
        const url = new URL(details.url);
        if (await isDomainAllowed(url.hostname)) return;

        const filtered = (details.responseHeaders || []).filter(
          h => h.name.toLowerCase() !== "set-cookie"
        );

        if (filtered.length !== (details.responseHeaders || []).length) {
          console.warn("[COOKIE_GUARD] Set-Cookie stripped", {
            url: details.url,
            tabId: details.tabId
          });
          return { responseHeaders: filtered };
        }
      } catch (err) {
        console.error("[COOKIE_GUARD] error, failing closed", err);
        const filtered = (details.responseHeaders || []).filter(
          h => h.name.toLowerCase() !== "set-cookie"
        );
        return { responseHeaders: filtered };
      }
    },
    { urls: ["<all_urls>"] },
    ["blocking", "responseHeaders", "extraHeaders"]
  );

  console.info("[COOKIE_GUARD] deny-by-default cookie enforcement active");
})();