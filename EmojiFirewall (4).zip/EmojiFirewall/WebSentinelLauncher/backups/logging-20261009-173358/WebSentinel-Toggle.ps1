﻿$ErrorActionPreference = 'Stop'

$launcherHome = 'J:\EmojiFirewall\WebSentinelLauncher'
$extDir = 'J:\EmojiFirewall\BrowserExtension'
$proj = 'J:\EmojiFirewall\SidebarFirewall\SidebarFirewall.csproj'
$logs = Join-Path $launcherHome 'logs'
$state = Join-Path $launcherHome 'running.json'
$receiverScript = Join-Path $extDir 'web_sentinel_log_server.py'
$receiverPort = 2222

New-Item -ItemType Directory -Force -Path $logs | Out-Null

# Toggle OFF: stop only the process trees this launcher started.
if (Test-Path $state) {
    $s = Get-Content $state -Raw | ConvertFrom-Json
    foreach ($id in @([int]$s.WebExtPid, [int]$s.ProxyPid, [int]$s.ReceiverPid)) {
        if ($id -gt 0 -and (Get-Process -Id $id -ErrorAction SilentlyContinue)) {
            & taskkill.exe /PID $id /T /F 2>$null | Out-Null
        }
    }
    Remove-Item $state -Force
    Write-Host 'Web Sentinel launcher processes stopped. Logs retained.' -ForegroundColor Yellow
    exit
}

if (!(Test-Path (Join-Path $extDir 'manifest.json'))) { throw 'manifest.json not found.' }
if (!(Test-Path $proj)) { throw 'SidebarFirewall.csproj not found.' }

$proxyExe = 'J:\EmojiFirewall\SidebarFirewall\bin\Debug\net8.0\SidebarFirewall.exe'
$npx = Get-Command npx.cmd -ErrorAction SilentlyContinue
if (!$npx) { throw 'Node.js/npm is required. Install Node.js so npx.cmd is available.' }

$firefox = @(
    "$env:ProgramFiles\Mozilla Firefox\firefox.exe",
    "${env:ProgramFiles(x86)}\Mozilla Firefox\firefox.exe"
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if (!$firefox) { throw 'Firefox executable not found in standard install folders.' }

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$proxyOut = Join-Path $logs "proxy-$stamp.out.log"
$proxyErr = Join-Path $logs "proxy-$stamp.err.log"
$webOut = Join-Path $logs "web-ext-$stamp.out.log"
$webErr = Join-Path $logs "web-ext-$stamp.err.log"
$receiverOut = Join-Path $logs "receiver-$stamp.out.log"
$receiverErr = Join-Path $logs "receiver-$stamp.err.log"

Write-Host 'Starting proxy...'
$p = Start-Process -FilePath $proxyExe `
    -ArgumentList @('--proxy') `
    -WorkingDirectory (Split-Path $proxyExe) `
    -RedirectStandardOutput $proxyOut `
    -RedirectStandardError $proxyErr -PassThru

Start-Sleep -Seconds 2
if ($p.HasExited) { throw "Proxy exited. Review $proxyErr" }

Write-Host 'Launching Firefox with the existing extension folder...'
$w = Start-Process -FilePath $npx.Source `
    -ArgumentList @('--yes','web-ext','run','--source-dir',$extDir,'--firefox',$firefox) `
    -WorkingDirectory $extDir `
    -RedirectStandardOutput $webOut `
    -RedirectStandardError $webErr -PassThru

Start-Sleep -Seconds 3
if ($w.HasExited) {
    & taskkill.exe /PID $p.Id /T /F 2>$null | Out-Null
    throw "web-ext exited. Review $webErr"
}

# Log receiver: started last so the failure paths above need no cleanup.
$receiverPid = 0
$py = Get-Command python.exe -ErrorAction SilentlyContinue
$portBusy = Get-NetTCPConnection -LocalPort $receiverPort -State Listen -ErrorAction SilentlyContinue
if ($portBusy) {
    Write-Warning "Port $receiverPort already in use; log receiver not started."
} elseif (!$py -or !(Test-Path $receiverScript)) {
    Write-Warning 'python.exe or web_sentinel_log_server.py not found; log receiver not started.'
} else {
    Write-Host 'Starting log receiver...'
    $r = Start-Process -FilePath $py.Source `
        -ArgumentList @('-u', "`"$receiverScript`"") `
        -WorkingDirectory $extDir `
        -WindowStyle Hidden `
        -RedirectStandardOutput $receiverOut `
        -RedirectStandardError $receiverErr -PassThru
    Start-Sleep -Seconds 1
    if ($r.HasExited) {
        Write-Warning "Log receiver exited. Review $receiverErr"
    } else {
        $receiverPid = $r.Id
    }
}

@{
    ProxyPid = $p.Id
    WebExtPid = $w.Id
    ReceiverPid = $receiverPid
    Started = (Get-Date).ToString('o')
    ProxyLog = $proxyOut
    ProxyErrorLog = $proxyErr
    FirefoxLog = $webOut
    FirefoxErrorLog = $webErr
    ReceiverLog = $receiverOut
    ReceiverErrorLog = $receiverErr
} | ConvertTo-Json | Set-Content -Path $state -Encoding UTF8

Write-Host 'Launcher started.' -ForegroundColor Green
Write-Host "Logs: $logs"