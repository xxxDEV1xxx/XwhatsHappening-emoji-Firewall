﻿
$ErrorActionPreference = 'Stop'

$launcherHome = 'J:\EmojiFirewall\WebSentinelLauncher'
$target = Join-Path $launcherHome 'WebSentinel-Tray.ps1'

if (!(Test-Path -LiteralPath $target)) {
    throw "Tray script not found: $target"
}

$original = [System.IO.File]::ReadAllText($target)
$newline = if ($original.Contains("`r`n")) { "`r`n" } else { "`n" }
$source = $original.Replace("`r`n", "`n").Replace("`r", "`n")

function Normalize-Anchor([string]$value) {
    return $value.Replace("`r`n", "`n").Replace("`r", "`n").Trim([char[]]"`r`n")
}

function Replace-ExactlyOnce(
    [string]$text,
    [string]$anchor,
    [string]$replacement,
    [string]$label
) {
    $anchor = Normalize-Anchor $anchor
    $first = $text.IndexOf($anchor, [StringComparison]::Ordinal)

    if ($first -lt 0) {
        throw "PRECHECK FAILED: anchor not found: $label. No files have been changed."
    }

    $second = $text.IndexOf(
        $anchor, $first + $anchor.Length, [StringComparison]::Ordinal
    )

    if ($second -ge 0) {
        throw "PRECHECK FAILED: anchor occurs more than once: $label. No files have been changed."
    }

    return $text.Substring(0, $first) + $replacement +
        $text.Substring($first + $anchor.Length)
}

# Anchor 1: insert settings and log helpers before the menu is created.
$a1 = @'
$menu = New-Object System.Windows.Forms.ContextMenuStrip
'@

$r1 = @'
$script:settingsFile = Join-Path $launcherHome 'settings.json'
$script:eventLog = Join-Path $logs 'web-sentinel.jsonl'

function Get-LoggingConfig {
    $root = Get-Content -LiteralPath $script:settingsFile -Raw |
        ConvertFrom-Json

    if ($null -eq $root.logging) {
        throw 'The settings file has no logging section.'
    }

    return $root.logging
}

function Sync-LoggingMenu {
    try {
        $cfg = Get-LoggingConfig
        $loggingEnabledItem.Checked = [bool]$cfg.enabled
        $firewallDecisionsItem.Checked = [bool]$cfg.firewallDecisions
        $cookieEventsItem.Checked = [bool]$cfg.cookieEvents
    } catch {
        $statusItem.Text = "Logging settings error: $($_.Exception.Message)"
    }
}

function Set-LoggingSetting {
    param(
        [Parameter(Mandatory=$true)][string]$Key,
        [Parameter(Mandatory=$true)][bool]$Value
    )

    $root = Get-Content -LiteralPath $script:settingsFile -Raw |
        ConvertFrom-Json

    if ($null -eq $root.logging) {
        throw 'The settings file has no logging section.'
    }

    $root.logging | Add-Member -MemberType NoteProperty `
        -Name $Key -Value $Value -Force

    $json = $root | ConvertTo-Json -Depth 64
    $temp = "$script:settingsFile.tmp"
    $utf8 = New-Object System.Text.UTF8Encoding($false)

    try {
        [System.IO.File]::WriteAllText(
            $temp, $json + [Environment]::NewLine, $utf8
        )
        Move-Item -LiteralPath $temp -Destination $script:settingsFile -Force
    } finally {
        if (Test-Path -LiteralPath $temp) {
            Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
        }
    }
}

function Show-LoggingError {
    param([string]$Message)

    [System.Windows.Forms.MessageBox]::Show(
        $Message,
        'Web Sentinel logging',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}

$menu = New-Object System.Windows.Forms.ContextMenuStrip
'@

# Anchor 2: add logging controls to the existing tray menu.
$a2 = @'
$menu.Items.Add($statusItem) | Out-Null
'@

$r2 = @'
$menu.Items.Add($statusItem) | Out-Null
$menu.Items.Add('-') | Out-Null

$loggingEnabledItem = New-Object System.Windows.Forms.ToolStripMenuItem('Logging enabled')
$loggingEnabledItem.CheckOnClick = $true
$menu.Items.Add($loggingEnabledItem) | Out-Null

$firewallDecisionsItem = New-Object System.Windows.Forms.ToolStripMenuItem('Firewall decisions')
$firewallDecisionsItem.CheckOnClick = $true
$menu.Items.Add($firewallDecisionsItem) | Out-Null

$cookieEventsItem = New-Object System.Windows.Forms.ToolStripMenuItem('Cookie events')
$cookieEventsItem.CheckOnClick = $true
$menu.Items.Add($cookieEventsItem) | Out-Null

$openEventLogItem = New-Object System.Windows.Forms.ToolStripMenuItem('Open event log')
$menu.Items.Add($openEventLogItem) | Out-Null
'@

# Anchor 3: keep checkmarks synchronized with settings.
$a3 = @'
function Refresh-Tray {
    $s = Get-SentinelState
'@

$r3 = @'
function Refresh-Tray {
    Sync-LoggingMenu
    $s = Get-SentinelState
'@

# Anchor 4: wire the menu actions before the existing exit handler.
$a4 = @'
$exitItem.Add_Click({
'@

$r4 = @'
$loggingEnabledItem.Add_Click({
    try {
        Set-LoggingSetting -Key 'enabled' -Value $loggingEnabledItem.Checked
        Sync-LoggingMenu
    } catch {
        Show-LoggingError "Could not save logging settings.`r`n$($_.Exception.Message)"
        Sync-LoggingMenu
    }
})

$firewallDecisionsItem.Add_Click({
    try {
        Set-LoggingSetting -Key 'firewallDecisions' -Value $firewallDecisionsItem.Checked
        Sync-LoggingMenu
    } catch {
        Show-LoggingError "Could not save firewall logging settings.`r`n$($_.Exception.Message)"
        Sync-LoggingMenu
    }
})

$cookieEventsItem.Add_Click({
    try {
        Set-LoggingSetting -Key 'cookieEvents' -Value $cookieEventsItem.Checked
        Sync-LoggingMenu
    } catch {
        Show-LoggingError "Could not save cookie logging settings.`r`n$($_.Exception.Message)"
        Sync-LoggingMenu
    }
})

$openEventLogItem.Add_Click({
    try {
        if (!(Test-Path -LiteralPath $script:eventLog)) {
            New-Item -ItemType Directory -Path $logs -Force | Out-Null
            [System.IO.File]::WriteAllText(
                $script:eventLog, '', (New-Object System.Text.UTF8Encoding($false))
            )
        }

        Start-Process -FilePath 'notepad.exe' `
            -ArgumentList "`"$script:eventLog`""
    } catch {
        Show-LoggingError "Could not open the event log.`r`n$($_.Exception.Message)"
    }
})

$exitItem.Add_Click({
'@

# Preflight all four anchors in memory before making any writes.
$source = Replace-ExactlyOnce $source $a1 $r1 'menu initialization'
$source = Replace-ExactlyOnce $source $a2 $r2 'menu logging controls'
$source = Replace-ExactlyOnce $source $a3 $r3 'tray refresh'
$source = Replace-ExactlyOnce $source $a4 $r4 'menu event handlers'

# Preserve the original file's newline convention.
if ($newline -eq "`r`n") {
    $source = $source.Replace("`n", "`r`n")
}

# Back up and replace only after every anchor passes.
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupDir = Join-Path $launcherHome "backups\tray-logging-$stamp"
New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
Copy-Item -LiteralPath $target `
    -Destination (Join-Path $backupDir 'WebSentinel-Tray.ps1')

$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($target, $source, $utf8NoBom)

Write-Host 'Tray logging patch applied.'
Write-Host "Backup: $backupDir"
Write-Host 'Added: global logging, firewall-decision logging, cookie-event logging, Open event log.'
```

