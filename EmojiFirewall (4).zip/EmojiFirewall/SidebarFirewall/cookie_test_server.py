from http.server import BaseHTTPRequestHandler, HTTPServer

class H(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Set-Cookie", "testcookie=1; Path=/; HttpOnly")
        self.send_header("Set-Cookie", "second=2; Secure; SameSite=Lax")
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", "2")
        self.end_headers()
        self.wfile.write(b"ok")

HTTPServer(("127.0.0.1", 8766), H).serve_forever()