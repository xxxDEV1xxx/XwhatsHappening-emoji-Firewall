using System;
using System.IO;
using System.Text.Json.Nodes;

internal static class FirewallSettings
{
    private const string ConfigPath =
        @"J:\EmojiFirewall\WebSentinelLauncher\settings.json";

    private static readonly object Gate = new object();
    private static DateTime _stamp = DateTime.MinValue;
    private static JsonNode? _root;

    // Firewall switches fail closed (on); logging fails off.
    public static bool FirewallEnabled(string key) =>
        Read("firewall", "enabled", true) && Read("firewall", key, true);

    public static bool LoggingEnabled(string key) =>
        Read("logging", "enabled", false) && Read("logging", key, false);

    private static bool Read(string section, string key, bool fallback)
    {
        try
        {
            lock (Gate)
            {
                var stamp = File.GetLastWriteTimeUtc(ConfigPath);
                if (_root is null || stamp != _stamp)
                {
                    _root = JsonNode.Parse(File.ReadAllText(ConfigPath));
                    _stamp = stamp;
                }
                var value = _root?[section]?[key];
                return value is null ? fallback : value.GetValue<bool>();
            }
        }
        catch
        {
            return fallback;
        }
    }
}

internal static class CookieLog
{
    public static void WriteLine(string message)
    {
        if (FirewallSettings.LoggingEnabled("cookieEvents"))
            Console.WriteLine(message);
    }

    public static void WriteLine(string format, params object?[] args)
    {
        if (FirewallSettings.LoggingEnabled("cookieEvents"))
            Console.WriteLine(format, args);
    }
}