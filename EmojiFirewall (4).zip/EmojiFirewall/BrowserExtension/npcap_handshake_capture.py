#!/usr/bin/env python3
"""Npcap/Scapy passive network event capture for Web Sentinel."""
import argparse
import json
import sys
import time
from datetime import datetime, timezone
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from scapy.all import sniff, conf, get_if_list, IP, IPv6, TCP, UDP, DNS, Raw

DEFAULT_LOGGER = "http://127.0.0.1:2222/log"
_seen = {}
DEDUP_SECONDS = 2.0


def timestamp(packet):
    return datetime.fromtimestamp(float(packet.time), timezone.utc).isoformat(timespec="microseconds")


def addresses(packet):
    if IP in packet:
        return "IPv4", packet[IP].src, packet[IP].dst
    if IPv6 in packet:
        return "IPv6", packet[IPv6].src, packet[IPv6].dst
    return None, None, None


def duplicate(key):
    now = time.monotonic()
    old = _seen.get(key)
    _seen[key] = now
    if len(_seen) > 12000:
        for k, t in list(_seen.items()):
            if now - t > DEDUP_SECONDS:
                _seen.pop(k, None)
    return old is not None and now - old < DEDUP_SECONDS


def send(endpoint, entry):
    req = Request(endpoint, data=json.dumps(entry, separators=(",", ":")).encode(),
                  headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urlopen(req, timeout=3) as response:
            return 200 <= response.status < 300
    except (URLError, HTTPError, TimeoutError, OSError) as exc:
        print(f"[ERROR] Logger unavailable: {exc}", file=sys.stderr)
        return False


def emit(endpoint, event_type, packet, **details):
    version, src, dst = addresses(packet)
    entry = {"timestampUtc": timestamp(packet), "eventType": event_type,
             "ipVersion": version, "sourceIp": src, "destinationIp": dst,
             "details": details}
    if TCP in packet:
        entry.update(sourcePort=int(packet[TCP].sport), destinationPort=int(packet[TCP].dport),
                     tcpFlags=int(packet[TCP].flags))
    elif UDP in packet:
        entry.update(sourcePort=int(packet[UDP].sport), destinationPort=int(packet[UDP].dport))
    if send(endpoint, entry):
        desc = details.get("queryName") or details.get("sni") or details.get("event") or details.get("protocol", "")
        print(f"{entry['timestampUtc']} {event_type} {src}:{entry.get('sourcePort', '')} -> {dst}:{entry.get('destinationPort', '')} {desc}")


def decode_tls_client_hello(payload):
    """Recognize a complete TLS ClientHello carried in one TCP payload (best effort)."""
    if len(payload) < 9 or payload[0] != 0x16 or payload[1] != 0x03:
        return None
    record_len = int.from_bytes(payload[3:5], "big")
    if record_len < 4 or len(payload) < 5 + record_len:
        return None
    hs = payload[5:5 + record_len]
    if hs[0] != 1:
        return None
    hs_len = int.from_bytes(hs[1:4], "big")
    if hs_len + 4 > len(hs):
        return None
    body = hs[4:4 + hs_len]
    try:
        p = 34
        p += 1 + body[p]  # session id
        cipher_len = int.from_bytes(body[p:p + 2], "big")
        p += 2 + cipher_len
        p += 1 + body[p]  # compression methods
        if p == len(body):
            return {"sni": None, "legacyVersion": f"0x{payload[1]:02x}{payload[2]:02x}"}
        ext_len = int.from_bytes(body[p:p + 2], "big")
        p += 2
        end = min(p + ext_len, len(body))
        while p + 4 <= end:
            typ = int.from_bytes(body[p:p + 2], "big")
            size = int.from_bytes(body[p + 2:p + 4], "big")
            ext = body[p + 4:p + 4 + size]
            p += 4 + size
            if typ == 0 and len(ext) >= 5:
                q = 2
                list_end = min(2 + int.from_bytes(ext[:2], "big"), len(ext))
                while q + 3 <= list_end:
                    name_type = ext[q]
                    name_len = int.from_bytes(ext[q + 1:q + 3], "big")
                    name = ext[q + 3:q + 3 + name_len]
                    if name_type == 0 and len(name) == name_len:
                        return {"sni": name.decode("idna", "replace"), "legacyVersion": f"0x{payload[1]:02x}{payload[2]:02x}"}
                    q += 3 + name_len
        return {"sni": None, "legacyVersion": f"0x{payload[1]:02x}{payload[2]:02x}"}
    except (IndexError, ValueError):
        return None


def handle(packet, endpoint):
    version, src, dst = addresses(packet)
    if not version:
        return
    if TCP in packet:
        tcp = packet[TCP]
        flags = int(tcp.flags)
        flow = (version, src, int(tcp.sport), dst, int(tcp.dport))
        if flags & 0x02:
            event = "SYN_ACK" if flags & 0x10 else "SYN"
            if not duplicate(("tcp", event, flow)):
                emit(endpoint, "tcp.handshake", packet, event=event,
                     description="TCP SYN-ACK reply" if event == "SYN_ACK" else "TCP SYN connection attempt")
            # SYN without ACK to local/private host is an inbound attempt.
            if not (flags & 0x10) and (dst.startswith("192.168.") or dst.startswith("10.") or dst.startswith("172.")):
                if not duplicate(("inbound", flow)):
                    emit(endpoint, "network.inbound", packet, protocol="TCP", event="SYN",
                         description="Inbound TCP connection attempt; verify direction/host")
        if Raw in packet and (int(tcp.dport) in (443, 8443) or int(tcp.sport) in (443, 8443)):
            parsed = decode_tls_client_hello(bytes(packet[Raw].load))
            if parsed and not duplicate(("tls", flow, parsed.get("sni"))):
                emit(endpoint, "tls.handshake", packet, event="CLIENT_HELLO",
                     handshakeType="ClientHello", sni=parsed.get("sni"),
                     legacyVersion=parsed.get("legacyVersion"),
                     parserNote="Best effort; complete ClientHello must be present in one TCP packet")
        return
    if UDP in packet:
        udp = packet[UDP]
        if DNS in packet and int(packet[DNS].qr) == 0 and packet[DNS].qd is not None:
            dns = packet[DNS]
            try:
                qname = dns.qd.qname.decode("utf-8", "replace").rstrip(".") if isinstance(dns.qd.qname, bytes) else str(dns.qd.qname).rstrip(".")
                qtype = int(dns.qd.qtype)
            except (AttributeError, TypeError, ValueError):
                qname, qtype = "", None
            key = ("dns", src, int(udp.sport), dst, int(udp.dport), int(dns.id), qname, qtype)
            if qname and not duplicate(key):
                emit(endpoint, "dns.query", packet, queryName=qname, queryType=qtype,
                     dnsTransactionId=int(dns.id), transport="UDP", description="Decoded DNS query")
        # A QUIC-like long header is only a classification hint, not proof of a handshake.
        if (int(udp.dport) == 443 or int(udp.sport) == 443) and Raw in packet:
            payload = bytes(packet[Raw].load)
            if len(payload) >= 6 and payload[0] & 0xC0 == 0xC0:
                key = ("quic", src, int(udp.sport), dst, int(udp.dport), payload[:5])
                if not duplicate(key):
                    emit(endpoint, "network.alert", packet, protocol="QUIC",
                         event="QUIC_LONG_HEADER_PACKET", quicVersion="0x" + payload[1:5].hex(),
                         description="QUIC-like long-header packet; handshake not fully decoded")


def main():
    parser = argparse.ArgumentParser(description="Capture TCP, DNS, TLS ClientHello and QUIC-like packets using Npcap/Scapy.")
    parser.add_argument("--iface", help="Npcap interface name; defaults to Scapy's default interface.")
    parser.add_argument("--logger", default=DEFAULT_LOGGER, help=f"Receiver URL (default: {DEFAULT_LOGGER})")
    parser.add_argument("--list-interfaces", action="store_true", help="List interfaces and exit.")
    args = parser.parse_args()
    if args.list_interfaces:
        print("Available interfaces:")
        for interface in get_if_list():
            print(f"  {interface}")
        print(f"Default interface: {conf.iface}")
        return
    iface = args.iface or str(conf.iface)
    print(f"Capturing TCP, DNS, TLS ClientHello and QUIC-like packets on: {iface}")
    print(f"Sending events to: {args.logger}")
    print("TLS classification is best-effort; QUIC is reported as network.alert, not a confirmed handshake.")
    print("Press Ctrl+C to stop.")
    try:
        sniff(iface=iface, filter="ip or ip6", prn=lambda p: handle(p, args.logger), store=False)
    except KeyboardInterrupt:
        print("\nCapture stopped.")
    except (PermissionError, OSError) as exc:
        print(f"Capture failed: {exc}", file=sys.stderr)
        print("Check Npcap, interface name, and elevated capture permissions.", file=sys.stderr)
        raise SystemExit(1)

if __name__ == "__main__":
    main()
