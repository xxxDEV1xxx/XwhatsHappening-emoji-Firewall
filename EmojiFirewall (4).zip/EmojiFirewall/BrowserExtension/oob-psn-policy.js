﻿"use strict";
(() => {
  if (globalThis.OOBGuard && globalThis.PSNPolicy) return;

  const B = Object.freeze({
    WS_MESSAGE: 65536, POST_CONTENT: 500, REPLY_CONTENT: 500,
    DM_PLAINTEXT: 10000, DM_PASSPHRASE: 500, DM_PASSPHRASE_MIN: 12,
    DISPLAY_NAME: 50, BIO: 200, HINT: 100, SEARCH_QUERY: 256,
    USERNAME: 50, AVATAR_URL: 2048, FIRESIDE_DOC: 2097152,
    FIRESIDE_URL: 2048, FEED_ITEMS: 200, LINKIFY_INPUT: 2000,
    CAMPFIRE_LINE: 80, TOKEN_COLOR_STORE: 4096,
    PSN_VIOLATION_LOG: 512, UPLOAD_FILENAME: 255
  });

  const encoder = new TextEncoder();
  const bytes = s => encoder.encode(s).length;

  class OOBViolation extends Error {
    constructor(source, value, bound) {
      super(`OOB[${source}]: ${value} exceeds or violates bound ${bound}`);
      this.name = "OOBViolation";
      this.source = source;
      this.value = value;
      this.bound = bound;
    }
  }

  function guard(n, bound, source) {
    if (!Number.isSafeInteger(n) || n < 0 || n > bound)
      throw new OOBViolation(source, n, bound);
    return n;
  }

  function guardStr(s, bound, source = "string") {
    if (typeof s !== "string") throw new OOBViolation(source, -1, bound);
    guard(bytes(s), bound, source);
    return s;
  }

  function clamp(s, maxBytes, source = "clamp") {
    if (typeof s !== "string") return "";
    let out = "", used = 0;
    for (const ch of s) {
      const n = bytes(ch);
      if (used + n > maxBytes) break;
      out += ch;
      used += n;
    }
    if (out !== s) console.warn("[OOB_GUARD] CLAMPED", source, bytes(s), used);
    return out;
  }

  function record(type, chars, description, risk) {
    const hex = Array.from(chars, c =>
      c.codePointAt(0).toString(16).padStart(4, "0")).join(",");
    const entry = clamp(`PSN1:${type}:${hex}:${description}:${risk}`,
      B.PSN_VIOLATION_LOG, "psn_record");
    console.warn("[PSN_VIOLATION]", entry);
    return entry;
  }

  const bidiRE = /[\u202a-\u202e\u2066-\u2069]/g;
  const zeroWidthRE = /[\u200b-\u200d\ufeff]/g;
  const homoglyphRE = /[\u0430\u0435\u043e\u0440\u0441\u0445\u0438\u0439\u043a\u043c\u043d\u0440\u0442\u0432]/g;

  function strip(s) {
    if (typeof s !== "string") return s;
    const bidi = s.match(bidiRE);
    const zw = s.match(zeroWidthRE);
    const hg = s.match(homoglyphRE);
    if (bidi) record("BIDI", bidi, "BiDi control characters", "HIGH");
    if (zw) record("ZERO_WIDTH", zw, "Invisible characters", "MEDIUM");
    if (hg) record("HOMOGLYPH", hg, "Cyrillic homoglyph retained", "LOW");
    return s.replace(bidiRE, "").replace(zeroWidthRE, "");
  }

  function isolate(value) {
    const span = document.createElement("span");
    span.style.unicodeBidi = "isolate";
    span.textContent = strip(String(value ?? ""));
    return span;
  }

  function checkFilename(name) {
    if (typeof name !== "string" || !name)
      return { allowed: true, safe: name, violations: [] };

    const violations = [];
    if (bytes(name) > B.UPLOAD_FILENAME)
      violations.push({ type: "OOB_FILENAME_LENGTH", risk: "HIGH" });
    if (/[\u202a-\u202e\u2066-\u2069\u200b-\u200d\ufeff]/.test(name))
      violations.push({ type: "UNICODE_FILENAME_CONTROL", risk: "HIGH" });

    const safe = strip(name);
    return {
      allowed: violations.length === 0,
      safe,
      violations
    };
  }

  const OOBGuard = Object.freeze({
    B, OOBViolation, bytes, guard, guardStr, clamp,
    postContent: s => guardStr(s, B.POST_CONTENT, "post_content"),
    replyContent: s => guardStr(s, B.REPLY_CONTENT, "reply_content"),
    dmPlaintext: s => guardStr(s, B.DM_PLAINTEXT, "dm_plaintext"),
    dmPassphrase: s => {
      guardStr(s, B.DM_PASSPHRASE, "dm_passphrase");
      guard(bytes(s), Number.MAX_SAFE_INTEGER, "passphrase_bytes");
      if (bytes(s) < B.DM_PASSPHRASE_MIN)
        throw new OOBViolation("dm_passphrase_min", bytes(s), B.DM_PASSPHRASE_MIN);
      return s;
    },
    displayName: s => guardStr(s, B.DISPLAY_NAME, "display_name"),
    bio: s => guardStr(s, B.BIO, "bio"),
    searchQuery: s => guardStr(s, B.SEARCH_QUERY, "search_query"),
    wsMessage: s => guardStr(s, B.WS_MESSAGE, "ws_message"),
    firesideDoc: s => guardStr(s, B.FIRESIDE_DOC, "fireside_doc"),
    firesideUrl: s => guardStr(s, B.FIRESIDE_URL, "fireside_url"),
    linkifyInput: s => guardStr(s, B.LINKIFY_INPUT, "linkify_input"),
    uploadFilename: s => guardStr(s, B.UPLOAD_FILENAME, "upload_filename")
  });

  const PSNPolicy = Object.freeze({ strip, isolate, record, checkFilename });

  Object.defineProperty(globalThis, "OOBGuard", {
    value: OOBGuard, configurable: false, writable: false
  });
  Object.defineProperty(globalThis, "PSNPolicy", {
    value: PSNPolicy, configurable: false, writable: false
  });

  console.info("[OOB_PSN] Policy core loaded");
})();
