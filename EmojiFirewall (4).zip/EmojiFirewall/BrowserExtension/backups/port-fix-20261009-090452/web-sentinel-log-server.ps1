﻿$ErrorActionPreference = "Stop"
$logPath = Join-Path $PSScriptRoot "logs\web-sentinel.jsonl"
New-Item -ItemType Directory -Force (Split-Path $logPath) | Out-Null
$listener = [System.Net.Sockets.TcpListener]::new(
    [System.Net.IPAddress]::Loopback, 8787
)
$mutex = [System.Threading.Mutex]::new($false, "WebSentinelUnifiedLog")
$utf8 = [System.Text.UTF8Encoding]::new($false)

function Read-Exact($stream, [int]$count) {
    $buffer = [byte[]]::new($count)
    $offset = 0
    while ($offset -lt $count) {
        $n = $stream.Read($buffer, $offset, $count - $offset)
        if ($n -le 0) { throw "Client disconnected" }
        $offset += $n
    }
    return ,$buffer
}

try {
    $listener.Start()
    Write-Host "Web Sentinel log receiver listening on 127.0.0.1:8787"
    Write-Host "Appending firewall violations to $logPath"
    Write-Host "Press Ctrl+C to stop."
    while ($true) {
        $client = $listener.AcceptTcpClient()
        try {
            $stream = $client.GetStream()
            $stream.ReadTimeout = 5000
            $reader = [System.IO.StreamReader]::new(
                $stream, [System.Text.Encoding]::ASCII, $false, 1024, $true
            )
            $requestLine = $reader.ReadLine()
            $headers = @{}
            while ($true) {
                $line = $reader.ReadLine()
                if ([string]::IsNullOrEmpty($line)) { break }
                $colon = $line.IndexOf(":")
                if ($colon -gt 0) {
                    $headers[$line.Substring(0, $colon).Trim().ToLowerInvariant()] =
                        $line.Substring($colon + 1).Trim()
                }
            }

            $status = "400 Bad Request"
            if ($requestLine -match '^POST /log HTTP/1\.[01]$' -and
                $headers.ContainsKey("content-length")) {
                $length = 0
                if ([int]::TryParse($headers["content-length"], [ref]$length) -and
                    $length -gt 0 -and $length -le 65536) {
                    $bodyBytes = Read-Exact $stream $length
                    $body = $utf8.GetString($bodyBytes)
                    try {
                        $entry = $body | ConvertFrom-Json -ErrorAction Stop
                        if ($entry.eventType -eq "firewall.violation") {
                            if (-not $entry.timestampUtc) {
                                $entry | Add-Member -NotePropertyName timestampUtc `
                                    -NotePropertyValue ([DateTime]::UtcNow.ToString("o"))
                            }
                            $line = ($entry | ConvertTo-Json -Compress -Depth 8) +
                                "`n"
                            [void]$mutex.WaitOne()
                            try {
                                [System.IO.File]::AppendAllText(
                                    $logPath, $line, $utf8
                                )
                            } finally {
                                $mutex.ReleaseMutex()
                            }
                            $status = "200 OK"
                        } else {
                            $status = "400 Bad Request"
                        }
                    } catch {
                        $status = "400 Bad Request"
                    }
                }
            }

            $response = "HTTP/1.1 $status`r`nContent-Length: 0`r`nConnection: close`r`n`r`n"
            $responseBytes = [System.Text.Encoding]::ASCII.GetBytes($response)
            $stream.Write($responseBytes, 0, $responseBytes.Length)
        } catch {
            Write-Warning ("Log receiver request failed: " + $_.Exception.Message)
        } finally {
            $client.Close()
        }
    }
} finally {
    $listener.Stop()
    $mutex.Dispose()
}
