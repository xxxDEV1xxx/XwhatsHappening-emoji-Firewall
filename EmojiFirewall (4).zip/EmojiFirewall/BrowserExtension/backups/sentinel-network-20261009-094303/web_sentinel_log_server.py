
#!/usr/bin/env python3
"""Local Web Sentinel JSONL receiver, portable across Windows and Linux."""

from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json
import threading

HOST = "127.0.0.1"
PORT = 2222
LOG_PATH = Path(__file__).resolve().parent / "logs" / "web-sentinel.jsonl"
LOCK = threading.Lock()
ALLOWED_EVENTS = {"tcp.handshake", "firewall.violation"}


def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


class LogHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print("[HTTP] " + (fmt % args))

    def add_cors_headers(self):
        origin = self.headers.get("Origin", "")
        if origin.startswith("moz-extension://"):
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(204)
        self.add_cors_headers()
        self.end_headers()

    def do_POST(self):
        if self.path != "/log":
            self.send_error(404, "Expected /log")
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self.send_error(400, "Invalid Content-Length")
            return

        if not 1 <= length <= 65536:
            self.send_error(413, "Invalid body length")
            return

        try:
            entry = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            self.send_error(400, "Invalid JSON")
            return

        if not isinstance(entry, dict):
            self.send_error(400, "Expected a JSON object")
            return

        if entry.get("eventType") not in ALLOWED_EVENTS:
            self.send_error(400, "Unsupported eventType")
            return

        entry.setdefault("timestampUtc", utc_now())
        line = json.dumps(
            entry, ensure_ascii=False, separators=(",", ":")
        ) + "\n"

        try:
            LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
            with LOCK:
                with LOG_PATH.open("a", encoding="utf-8", newline="") as f:
                    f.write(line)
                    f.flush()
        except OSError as exc:
            print(f"[ERROR] Could not append log: {exc}")
            self.send_error(500, "Log write failed")
            return

        self.send_response(200)
        self.add_cors_headers()
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(b'{"ok":true}\n')
        print(f"[LOGGED] {entry['eventType']}")


def main():
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer((HOST, PORT), LogHandler)
    print(f"Web Sentinel receiver: http://{HOST}:{PORT}/log")
    print(f"Unified log: {LOG_PATH}")
    print("Accepted: tcp.handshake, firewall.violation")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping receiver.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
