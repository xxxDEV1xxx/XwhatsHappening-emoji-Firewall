﻿(() => {
    "use strict";

    const PREFIX = "[Web Sentinel]";
    const MAX_LOG_ENTRIES = 500;
    const logEntries = [];

    let rules = [];
    let observer = null;
    let configLoaded = false;

    function log(action, ruleId, details) {
        const entry = {
            time: new Date().toISOString(),
            action,
            ruleId,
            details: String(details || "").slice(0, 300),
            host: location.hostname
        };

        logEntries.push(entry);

        if (logEntries.length > MAX_LOG_ENTRIES)
            logEntries.shift();

        console.info(PREFIX, action, ruleId, entry.details);
    }

    function scan(root) {
        if (!configLoaded || !root)
            return;

        for (const rule of rules) {
            if (!rule.enabled || rule.type !== "dom-selector")
                continue;

            let matches = [];

            try {
                if (root instanceof Element &&
                    root.matches(rule.selector)) {
                    matches.push(root);
                }

                if (root.querySelectorAll) {
                    matches.push(
                        ...root.querySelectorAll(rule.selector)
                    );
                }
            } catch (error) {
                log("RULE_ERROR", rule.id, error.message);
                continue;
            }

            for (const element of matches) {
                if (!element.isConnected)
                    continue;

                if (rule.action === "remove") {
                    log("BLOCK_DOM", rule.id, element.tagName);
                    element.remove();
                }
            }
        }
    }

    console.info(
        PREFIX,
        "SCRIPT_STARTED",
        location.hostname,
        "document.readyState=" + document.readyState
    );

    async function initialize() {
        try {
            const api = globalThis.browser || globalThis.chrome;

            if (!api?.runtime?.getURL)
                throw new Error("Extension runtime API unavailable");

            const response = await fetch(
                api.runtime.getURL("sentinel-rules.json")
            );

            if (!response.ok)
                throw new Error(`Rules HTTP ${response.status}`);

            const config = await response.json();

            if (config.version !== 1 ||
                !Array.isArray(config.rules)) {
                throw new Error("Invalid Sentinel rules configuration");
            }

            rules = config.rules;
            configLoaded = true;

            log("POLICY_LOADED", "configuration", rules.length);

            scan(document.documentElement);

            if (!observer && document.documentElement) {
                observer = new MutationObserver(records => {
                    for (const record of records) {
                        for (const node of record.addedNodes) {
                            if (node instanceof Element)
                                scan(node);
                        }
                    }
                });

                observer.observe(document.documentElement, {
                    childList: true,
                    subtree: true
                });
            }
        } catch (error) {
            // A failed optional cosmetic policy must not break
            // the existing Emoji Firewall.
            console.error(PREFIX, "POLICY_INIT_FAILED", error);
        }
    }

    globalThis.WebSentinel = Object.freeze({
        getLog: () => logEntries.map(entry => ({ ...entry })),
        rescan: () => scan(document.documentElement)
    });

    if (document.documentElement) {
        initialize();
    } else {
        document.addEventListener(
            "DOMContentLoaded",
            initialize,
            { once: true }
        );
    }
})();

