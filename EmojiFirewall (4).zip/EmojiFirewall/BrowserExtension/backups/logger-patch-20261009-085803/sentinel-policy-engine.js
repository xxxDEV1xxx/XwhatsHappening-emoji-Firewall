﻿"use strict";

(function (root) {
    const VALID_DECISIONS = new Set([
        "allow", "block", "quarantine", "reject"
    ]);

    function normalizeHost(host) {
        return String(host || "")
            .trim()
            .toLowerCase()
            .replace(/\.$/, "");
    }

    function hostMatches(host, rule) {
        host = normalizeHost(host);
        rule = normalizeHost(rule).replace(/^\*\./, "");
        return !!host && !!rule &&
            (host === rule || host.endsWith("." + rule));
    }

    function result(decision, reason, ruleId) {
        return {
            decision: decision,
            reason: reason,
            ruleId: ruleId || "default",
            timestamp: new Date().toISOString()
        };
    }

    function safeFallback(rules) {
        const fallback = rules?.policy?.onInspectionError || "quarantine";
        return VALID_DECISIONS.has(fallback) ? fallback : "quarantine";
    }

    function normalizeHeaders(inputHeaders) {
        if (!Array.isArray(inputHeaders)) return [];
        return inputHeaders.map(h => ({
            name: String(h?.name || "").trim(),
            value: String(h?.value || "")
        }));
    }

    function evaluateHeaders(headers, rules, side) {
        const headerPolicy = rules.headers || {};
        const maxCount = headerPolicy.maxCount ||
            rules.limits?.maxHeaderCount || 80;
        const maxValue = headerPolicy.maxValueLength || 16384;
        const maxName = headerPolicy.maxNameLength || 256;

        if (headers.length > maxCount) {
            return result("reject",
                side + " header count exceeds limit (" + headers.length + ")",
                "headers.count");
        }

        const seenSecurity = new Map();
        const blockedNames = (side === "response"
            ? (headerPolicy.blockedResponseNames || headerPolicy.blockedNames || [])
            : (headerPolicy.blockedNames || [])
        ).map(n => String(n).toLowerCase());

        const securityNames = new Set(
            (headerPolicy.securityHeaderNames || []).map(n =>
                String(n).toLowerCase())
        );

        for (const header of headers) {
            const name = header.name.toLowerCase();
            const value = header.value;

            if (!name || name.length > maxName) {
                return result("reject",
                    "Malformed or oversized " + side + " header name",
                    "headers.invalid-name");
            }

            // RFC 7230 token for field-name
            if (/[^a-z0-9!#$%&'*+.^_`|~-]/i.test(name)) {
                return result("reject",
                    "Illegal character in " + side + " header name",
                    "headers.illegal-name");
            }

            if (/[\r\n\0]/.test(value)) {
                return result("reject",
                    side + " header value contains CR/LF/NUL",
                    "headers.invalid-value");
            }

            // Obs-fold / bare control chars (except HTAB)
            if (/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/.test(value)) {
                return result("reject",
                    side + " header value contains control characters",
                    "headers.control-chars");
            }

            if (value.length > maxValue) {
                return result("reject",
                    side + " header value exceeds length limit",
                    "headers.value-length");
            }

            if (blockedNames.some(b => name === b)) {
                return result("block",
                    side + " header name is blocked: " + name,
                    "headers.blocked-name");
            }

            if (headerPolicy.rejectOnDuplicateSecurityHeaders &&
                securityNames.has(name)) {
                if (seenSecurity.has(name)) {
                    return result("reject",
                        "Duplicate security header: " + name,
                        "headers.duplicate-security");
                }
                seenSecurity.set(name, true);
            }
        }

        return null;
    }

    function evaluateAds(url, host, rules) {
        const adPolicy = rules.adsAndTrackers || {};
        if (!adPolicy.enabled) return null;

        if ((adPolicy.blockHosts || []).some(rule => hostMatches(host, rule))) {
            return result("block",
                "Ad/tracker host matched block list",
                "adsAndTrackers.blockHosts");
        }

        const href = url.href;
        if ((adPolicy.blockPatterns || []).some(pattern =>
            typeof pattern === "string" &&
            pattern.length > 0 &&
            href.toLowerCase().includes(String(pattern).toLowerCase()))) {
            return result("block",
                "URL matched ad/tracker pattern",
                "adsAndTrackers.blockPatterns");
        }

        return null;
    }

    function evaluateRequest(input, rules) {
        const urlText = String(input.url || "");

        if (urlText.length > (rules.limits?.maxUrlLength || 8192)) {
            return result("reject", "URL exceeds configured length limit",
                "limits.url-length");
        }

        let url;
        try {
            url = new URL(urlText);
        } catch (_) {
            return result("reject", "Malformed URL", "url.malformed");
        }

        if (!["http:", "https:"].includes(url.protocol)) {
            return result("reject", "Unsupported network protocol",
                "url.protocol");
        }

        const host = normalizeHost(url.hostname);
        const domains = rules.domains || {};

        if ((domains.allow || []).some(rule => hostMatches(host, rule))) {
            return result("allow", "Explicit domain allow rule",
                "domains.allow");
        }

        if ((domains.block || []).some(rule => hostMatches(host, rule))) {
            return result("block", "Domain matched block list",
                "domains.block");
        }

        const adHit = evaluateAds(url, host, rules);
        if (adHit) return adHit;

        const urlPolicy = rules.urls || {};
        if ((urlPolicy.allowPatterns || []).some(pattern =>
            typeof pattern === "string" && url.href.includes(pattern))) {
            return result("allow", "Explicit URL allow rule",
                "urls.allowPatterns");
        }

        if ((urlPolicy.blockPatterns || []).some(pattern =>
            typeof pattern === "string" && url.href.includes(pattern))) {
            return result("block", "URL matched block pattern",
                "urls.blockPatterns");
        }

        const headers = normalizeHeaders(input.headers);
        const headerDecision = evaluateHeaders(headers, rules, "request");
        if (headerDecision) return headerDecision;

        const contentType = String(input.contentType || "")
            .split(";")[0].trim().toLowerCase();

        if ((rules.contentTypes?.block || []).some(type =>
            contentType === String(type).toLowerCase())) {
            return result("block", "Content type matched block list",
                "contentTypes.block");
        }

        const decision = rules.policy?.defaultDecision || "allow";
        if (!VALID_DECISIONS.has(decision)) {
            return result("quarantine", "Invalid default policy decision",
                "policy.invalid-default");
        }

        return result(decision, "No blocking rule matched", "default");
    }

    function evaluateResponse(input, rules) {
        if (!rules.response?.enabled) {
            return result("allow", "Response inspection disabled", "response.off");
        }

        const urlText = String(input.url || "");
        let url;
        try {
            url = new URL(urlText);
        } catch (_) {
            return result("reject", "Malformed response URL", "url.malformed");
        }

        const host = normalizeHost(url.hostname);

        // Ads on response path too (redirect targets / late loads)
        const adHit = evaluateAds(url, host, rules);
        if (adHit) return adHit;

        const headers = normalizeHeaders(input.headers);
        const headerDecision = evaluateHeaders(headers, rules, "response");
        if (headerDecision) return headerDecision;

        // Content-Type
        let contentType = "";
        let contentLength = null;
        let disposition = "";

        for (const h of headers) {
            const n = h.name.toLowerCase();
            if (n === "content-type") {
                contentType = h.value.split(";")[0].trim().toLowerCase();
            } else if (n === "content-length") {
                const nVal = Number(h.value.trim());
                if (!Number.isFinite(nVal) || nVal < 0 ||
                    String(Math.floor(nVal)) !== h.value.trim()) {
                    return result("reject",
                        "Malformed Content-Length",
                        "response.content-length");
                }
                contentLength = nVal;
            } else if (n === "content-disposition") {
                disposition = h.value.toLowerCase();
            }
        }

        if (rules.response.rejectInvalidContentType && contentType) {
            // type/subtype basic shape
            if (!/^[a-z0-9!#$&^_.+-]+\/[a-z0-9!#$&^_.+-]+$/i.test(contentType)) {
                return result("reject",
                    "Malformed Content-Type",
                    "response.content-type");
            }
        }

        if ((rules.contentTypes?.block || []).some(type =>
            contentType === String(type).toLowerCase())) {
            return result("block",
                "Response content type blocked",
                "contentTypes.block");
        }

        const maxBytes = rules.response.maxBodyHintBytes ||
            rules.limits?.maxResponseBytes || 52428800;

        if (contentLength !== null && contentLength > maxBytes) {
            return result("reject",
                "Content-Length exceeds configured maximum",
                "response.size");
        }

        if (rules.response.rejectConflictingDisposition &&
            disposition.includes("attachment") &&
            (contentType.startsWith("text/html") ||
             contentType.startsWith("image/") ||
             contentType === "application/javascript" ||
             contentType === "text/javascript")) {
            // Suspicious combo; quarantine rather than hard block all downloads
            return result("quarantine",
                "Attachment disposition with navigable/script content type",
                "response.disposition-mismatch");
        }

        // Transfer-Encoding + Content-Length together is a classic smuggling signal
        let hasTE = false;
        let hasCL = contentLength !== null;
        for (const h of headers) {
            if (h.name.toLowerCase() === "transfer-encoding") {
                hasTE = true;
                const te = h.value.toLowerCase();
                if (te.includes("\r") || te.includes("\n")) {
                    return result("reject",
                        "Malformed Transfer-Encoding",
                        "response.transfer-encoding");
                }
                // chunked must be last if present (simplified)
                if (te.includes("chunked") &&
                    !te.trim().endsWith("chunked") &&
                    !/,?\s*chunked\s*$/i.test(te)) {
                    // keep soft — many stacks send odd TE; reject only obvious garbage
                }
            }
        }
        if (hasTE && hasCL) {
            return result("reject",
                "Both Transfer-Encoding and Content-Length present",
                "response.te-cl-conflict");
        }

        return result("allow", "Response passed validation", "response.ok");
    }

    function evaluate(input, rules, phase) {
        try {
            if (!input || !rules || rules.schemaVersion !== 1) {
                return result(
                    safeFallback(rules),
                    "Invalid input or unsupported rule schema",
                    "engine.invalid-input"
                );
            }

            const p = phase || input.phase || "request";
            if (p === "response") {
                return evaluateResponse(input, rules);
            }
            return evaluateRequest(input, rules);
        } catch (error) {
            return result(safeFallback(rules),
                "Policy evaluation failed: " + String(error?.message || error),
                "engine.exception");
        }
    }

    function logDecision(decision, context) {
        if (!decision || !VALID_DECISIONS.has(decision.decision)) {
            console.error("[Web Sentinel] Invalid decision record", decision);
            return;
        }

        const entry = {
            component: "WebSentinel",
            decision: decision.decision,
            reason: decision.reason,
            ruleId: decision.ruleId,
            timestamp: decision.timestamp,
            context: {
                url: String(context?.url || "").slice(0, 2048),
                method: String(context?.method || "").slice(0, 16),
                source: String(context?.source || "unknown").slice(0, 64)
            }
        };

        const method = decision.decision === "allow" ? "info" : "warn";
        console[method]("[Web Sentinel]", entry);
    }

    root.WebSentinelPolicy = Object.freeze({
        evaluate: evaluate,
        logDecision: logDecision,
        hostMatches: hostMatches
    });
})(globalThis);
