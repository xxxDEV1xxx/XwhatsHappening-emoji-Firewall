﻿"use strict";

(async function () {
    const PREFIX = "[Web Sentinel]";
    const LOGGER_URL = "http://127.0.0.1:8787/log";
    let rules;

    async function persistViolation(entry) {
        try {
            await fetch(LOGGER_URL, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(entry)
            });
        } catch (_) {}
    }

    function shouldPersist(decision) {
        return decision &&
            decision.decision !== "allow" &&
            decision.decision !== "default";
    }

    function log(decision, details, phase) {
        const entry = {
            eventType: "firewall.violation",
            component: "WebSentinelNetwork",
            phase: phase || "request",
            decision: decision.decision,
            reason: decision.reason,
            ruleId: decision.ruleId,
            url: String(details.url || "").slice(0, 2048),
            method: String(details.method || "").slice(0, 16),
            requestType: String(details.type || ""),
            statusCode: details.statusCode || undefined,
            timestampUtc: new Date().toISOString()
        };

        if (decision.decision === "allow") {
            if (rules?.policy?.logAllowed) console.info(PREFIX, entry);
            return;
        }

        console.warn(PREFIX, entry);
        persistViolation(entry);
    }

    function mapHeaders(detailsHeaders) {
        if (!Array.isArray(detailsHeaders)) return [];
        return detailsHeaders.map(h => ({
            name: String(h.name || ""),
            value: String(h.value || "")
        }));
    }

    function inspectBody(body) {
        if (!body) return false;

        const suspicious =
            /[\u202A-\u202E\u2066-\u2069\u200B-\u200D\uFEFF]/;

        function hasSuspicious(value) {
            if (typeof value !== "string") return false;
            if (suspicious.test(value)) return true;
            if (/\\u(?:202[a-e]|206[6-9]|200[b-d]|feff)/i.test(value)) {
                return true;
            }
            try {
                return suspicious.test(decodeURIComponent(value));
            } catch (_) {
                return false;
            }
        }

        if (body.formData) {
            for (const values of Object.values(body.formData)) {
                for (const value of values || []) {
                    if (hasSuspicious(value)) return true;
                }
            }
        }

        if (body.raw) {
            for (const part of body.raw) {
                if (!part.bytes) continue;
                try {
                    const bytes = new Uint8Array(part.bytes);
                    if (bytes.byteLength > 1024 * 1024) continue;
                    if (hasSuspicious(new TextDecoder("utf-8").decode(bytes))) {
                        return true;
                    }
                } catch (_) {}
            }
        }
        return false;
    }

    function cancelDecision(decision) {
        return decision.decision === "block" ||
            decision.decision === "reject" ||
            decision.decision === "quarantine";
    }

    try {
        let response = await fetch(
            browser.runtime.getURL("sentinel-firewall-rules.json")
        ).catch(() => null);

        if (!response || !response.ok) {
            response = await fetch(
                browser.runtime.getURL("sentinel-rules.json")
            );
        }
        if (!response.ok) {
            throw new Error("Rules fetch failed: " + response.status);
        }
        rules = await response.json();

        if (rules.schemaVersion !== 1) {
            throw new Error("Unsupported rules schema");
        }
        if (!globalThis.WebSentinelPolicy) {
            throw new Error("Policy engine failed to load");
        }

        const urlFilter = { urls: ["http://*/*", "https://*/*"] };

        // ---- Request URL / body / ads (early) ----
        browser.webRequest.onBeforeRequest.addListener(
            function (details) {
                try {
                    const decision = globalThis.WebSentinelPolicy.evaluate({
                        phase: "request",
                        url: details.url,
                        method: details.method,
                        type: details.type,
                        headers: [],
                        contentType: ""
                    }, rules, "request");

                    if (cancelDecision(decision)) {
                        log(decision, details, "request");
                        return { cancel: true };
                    }

                    if (inspectBody(details.requestBody)) {
                        const bodyDecision = {
                            decision: "block",
                            reason: "Request body contains bidi or zero-width controls",
                            ruleId: "unicode.request-body"
                        };
                        log(bodyDecision, details, "request");
                        return { cancel: true };
                    }

                    return {};
                } catch (error) {
                    const failure = {
                        decision: "quarantine",
                        reason: "Inspection exception: " +
                            String(error?.message || error),
                        ruleId: "engine.exception"
                    };
                    log(failure, details, "request");
                    return { cancel: true };
                }
            },
            urlFilter,
            ["blocking", "requestBody"]
        );

        // ---- Request headers ----
        browser.webRequest.onBeforeSendHeaders.addListener(
            function (details) {
                try {
                    const headers = mapHeaders(details.requestHeaders);
                    const decision = globalThis.WebSentinelPolicy.evaluate({
                        phase: "request",
                        url: details.url,
                        method: details.method,
                        type: details.type,
                        headers: headers,
                        contentType: ""
                    }, rules, "request");

                    // Re-check ads here in case of redirects / late binding
                    if (cancelDecision(decision)) {
                        log(decision, details, "request-headers");
                        return { cancel: true };
                    }

                    return { requestHeaders: details.requestHeaders };
                } catch (error) {
                    const failure = {
                        decision: "quarantine",
                        reason: "Header inspection exception: " +
                            String(error?.message || error),
                        ruleId: "engine.exception"
                    };
                    log(failure, details, "request-headers");
                    return { cancel: true };
                }
            },
            urlFilter,
            ["blocking", "requestHeaders"]
        );

        // ---- Response headers / MIME / size / TE+CL ----
        browser.webRequest.onHeadersReceived.addListener(
            function (details) {
                try {
                    const headers = mapHeaders(details.responseHeaders);
                    const decision = globalThis.WebSentinelPolicy.evaluate({
                        phase: "response",
                        url: details.url,
                        method: details.method,
                        type: details.type,
                        headers: headers,
                        statusCode: details.statusCode,
                        contentType: ""
                    }, rules, "response");

                    if (cancelDecision(decision)) {
                        log(decision, details, "response");
                        return { cancel: true };
                    }

                    return { responseHeaders: details.responseHeaders };
                } catch (error) {
                    const failure = {
                        decision: "quarantine",
                        reason: "Response inspection exception: " +
                            String(error?.message || error),
                        ruleId: "engine.exception"
                    };
                    log(failure, details, "response");
                    return { cancel: true };
                }
            },
            urlFilter,
            ["blocking", "responseHeaders"]
        );

        console.info(PREFIX,
            "Network guard registered (request + headers + response).");
        console.info(PREFIX,
            "Ad/tracker blocking:",
            !!(rules.adsAndTrackers && rules.adsAndTrackers.enabled),
            "hosts:",
            (rules.adsAndTrackers?.blockHosts || []).length);
    } catch (error) {
        console.error(PREFIX,
            "Network guard startup failed; interceptor not active.", error);
    }
})();
