###############################################################
#PS J:\EmojiFirewall\BrowserExtension> Two separate failures:
#
#     OOB/PSN - content-script chain was broken by the manifest rewrite.
#     Sites "blocked" - response/request header checks are too aggressive. GitHub's huge Cookie / Set-Cookie values exceed maxValueLength (16384) → reject → cancel. That matches Status 200 + 0 B body + only 1 request.
#
# Emergency fix: restore OOB/PSN, raise/skip cookie-size limits, and stop cancelling normal pages on soft response checks.
# powershell

 $ErrorActionPreference = "Stop"
 $ext = "J:\EmojiFirewall\BrowserExtension"
 $bak = "J:\backupfw"
 $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
 Set-Location $ext
 New-Item -ItemType Directory -Force ".\backups" | Out-Null

 function Find-Backup([string]$name) {
     $direct = Join-Path $bak $name
     if (Test-Path $direct) { return $direct }
     $hit = Get-ChildItem $bak -Recurse -Filter $name -File -EA SilentlyContinue |
         Select-Object -First 1 -ExpandProperty FullName
     return $hit
 }

 # ---- 1) Restore OOB / PSN / content from backupfw (do NOT touch request-guard yet) ----
 foreach ($n in @("oob-psn-policy.js","sentinel-policy.js","content.js","catalog.json")) {
     $src = Find-Backup $n
     if ($src) {
         Copy-Item $src (Join-Path $ext $n) -Force
         Write-Host "Restored $n"
     } else {
         Write-Host "NOT FOUND in backupfw: $n"
     }
 }

 # ---- 2) Manifest: OOB content scripts + network background (no module type) ----
 @'
 {
   "manifest_version": 3,
   "name": "Emoji Firewall",
   "version": "1.0.1",
   "description": "Emoji Firewall + Web Sentinel + OOB/PSN",
   "permissions": ["storage", "webRequest", "webRequestBlocking"],
   "host_permissions": ["<all_urls>"],
   "web_accessible_resources": [{
     "resources": ["catalog.json", "sentinel-rules.json", "sentinel-firewall-rules.json"],
     "matches": ["<all_urls>"]
   }],
   "content_scripts": [{
     "matches": ["<all_urls>"],
     "js": [
       "sentinel-policy.js",
       "oob-psn-policy.js",
       "sentinel-policy-engine.js",
       "content.js"
     ],
     "run_at": "document_start",
     "all_frames": true
   }],
   "background": {
     "scripts": ["sentinel-policy-engine.js", "request-guard.js"]
   }
 }
 '@ | Set-Content ".\manifest.json" -Encoding UTF8

 # ---- 3) Rules: keep ads, raise header limits, narrow patterns ----
 @'
 {
   "schemaVersion": 1,
   "policy": {
     "defaultDecision": "allow",
     "onInspectionError": "quarantine",
     "logAllowed": false
   },
   "limits": {
     "maxUrlLength": 8192,
     "maxHeaderCount": 120,
     "maxResponseBytes": 104857600
   },
   "domains": { "allow": [], "block": [] },
   "adsAndTrackers": {
     "enabled": true,
     "blockHosts": [
       "doubleclick.net",
       "googleadservices.com",
       "googlesyndication.com",
       "pagead2.googlesyndication.com",
       "adservice.google.com",
       "ad.doubleclick.net",
       "g.doubleclick.net",
       "googleads.g.doubleclick.net",
       "static.doubleclick.net",
       "cm.g.doubleclick.net",
       "adtrafficquality.google",
       "ep1.adtrafficquality.google",
       "ep2.adtrafficquality.google",
       "tpc.googlesyndication.com",
       "securepubads.g.doubleclick.net",
       "fundingchoicesmessages.google.com",
       "ads.youtube.com",
       "pagead2.googleadservices.com",
       "www.googleadservices.com",
       "partner.googleadservices.com",
       "google-analytics.com",
       "www.google-analytics.com",
       "ssl.google-analytics.com",
       "region1.google-analytics.com",
       "googletagmanager.com",
       "www.googletagmanager.com",
       "googletagservices.com",
       "amazon-adsystem.com",
       "aax.amazon-adsystem.com",
       "c.amazon-adsystem.com",
       "scorecardresearch.com",
       "quantserve.com",
       "outbrain.com",
       "taboola.com",
       "criteo.com",
       "criteo.net",
       "adnxs.com",
       "adsrvr.org",
       "moatads.com",
       "hotjar.com",
       "insights.hotjar.com",
       "segment.io",
       "segment.com",
       "mxpnl.com",
       "mixpanel.com",
       "bat.bing.com",
       "connect.facebook.net",
       "pixel.facebook.com",
       "static.ads-twitter.com",
       "ads-twitter.com",
       "analytics.twitter.com",
       "tr.snapchat.com",
       "2mdn.net",
       "s0.2mdn.net",
       "media.net",
       "pubmatic.com",
       "rubiconproject.com",
       "openx.net",
       "casalemedia.com",
       "bidswitch.net",
       "advertising.com",
       "adform.net",
       "yieldmo.com",
       "3lift.com",
       "liadm.com",
       "krxd.net",
       "bluekai.com",
       "demdex.net",
       "everesttech.net",
       "exelator.com",
       "rlcdn.com",
       "turn.com",
       "mathtag.com",
       "contextweb.com",
       "sharethrough.com",
       "teads.tv",
       "tremorhub.com",
       "spotxchange.com",
       "sonobi.com",
       "smartadserver.com",
       "stickyadstv.com",
       "adsafeprotected.com",
       "adsymptotic.com",
       "chartbeat.com",
       "newrelic.com",
       "nr-data.net",
       "optimizely.com",
       "parsely.com"
     ],
     "blockPatterns": [
       "://pagead2.googlesyndication.com/",
       "://googleads.g.doubleclick.net/",
       "://www.google-analytics.com/g/collect",
       "://www.google-analytics.com/collect",
       "://www.google-analytics.com/j/collect",
       "://region1.google-analytics.com/",
       "/pagead/s/cookie_push",
       "/pagead/gen_204",
       "getconfig/sodar",
       "/gtag/destination"
     ]
   },
   "urls": { "allowPatterns": [], "blockPatterns": [] },
   "headers": {
     "maxCount": 120,
     "maxValueLength": 131072,
     "maxNameLength": 256,
     "exemptValueLengthNames": [
       "cookie",
       "set-cookie",
       "authorization",
       "proxy-authorization",
       "x-client-data"
     ],
     "blockedNames": [
       "x-forwarded-host",
       "x-original-url",
       "x-rewrite-url"
     ],
     "blockedResponseNames": [],
     "rejectOnDuplicateSecurityHeaders": false,
     "securityHeaderNames": [
       "content-security-policy",
       "strict-transport-security",
       "x-frame-options",
       "x-content-type-options"
     ]
   },
   "contentTypes": {
     "block": [
       "application/x-msdownload",
       "application/x-msdos-program",
       "application/java-archive",
       "application/x-java-applet"
     ]
   },
   "response": {
     "enabled": true,
     "maxBodyHintBytes": 104857600,
     "rejectInvalidContentType": true,
     "rejectConflictingDisposition": false,
     "rejectTeClConflict": false
   }
 }
 '@ | Set-Content ".\sentinel-firewall-rules.json" -Encoding UTF8
 Copy-Item ".\sentinel-firewall-rules.json" ".\sentinel-rules.json" -Force

 # ---- 4) Policy engine: cookie-safe header limits, softer response ----
 @'
 "use strict";

 (function (root) {
     const VALID_DECISIONS = new Set(["allow", "block", "quarantine", "reject"]);

     function normalizeHost(host) {
         return String(host || "").trim().toLowerCase().replace(/\.$/, "");
     }

     function hostMatches(host, rule) {
         host = normalizeHost(host);
         rule = normalizeHost(rule).replace(/^\*\./, "");
         return !!host && !!rule && (host === rule || host.endsWith("." + rule));
     }

     function result(decision, reason, ruleId) {
         return {
             decision: decision,
             reason: reason,
             ruleId: ruleId || "default",
             timestamp: new Date().toISOString()
         };
     }

     function safeFallback(rules) {
         const fallback = rules?.policy?.onInspectionError || "quarantine";
         return VALID_DECISIONS.has(fallback) ? fallback : "quarantine";
     }

     function normalizeHeaders(inputHeaders) {
         if (!Array.isArray(inputHeaders)) return [];
         return inputHeaders.map(h => ({
             name: String(h?.name || "").trim(),
             value: String(h?.value || "")
         }));
     }

     function evaluateHeaders(headers, rules, side) {
         const headerPolicy = rules.headers || {};
         const maxCount = headerPolicy.maxCount || rules.limits?.maxHeaderCount || 120;
         const maxValue = headerPolicy.maxValueLength || 131072;
         const maxName = headerPolicy.maxNameLength || 256;
         const exempt = new Set(
             (headerPolicy.exemptValueLengthNames || [
                 "cookie", "set-cookie", "authorization", "proxy-authorization"
             ]).map(n => String(n).toLowerCase())
         );

         if (headers.length > maxCount) {
             return result("reject",
                 side + " header count exceeds limit (" + headers.length + ")",
                 "headers.count");
         }

         const blockedNames = (side === "response"
             ? (headerPolicy.blockedResponseNames || [])
             : (headerPolicy.blockedNames || [])
         ).map(n => String(n).toLowerCase());

         const securityNames = new Set(
             (headerPolicy.securityHeaderNames || []).map(n => String(n).toLowerCase())
         );
         const seenSecurity = new Map();

         for (const header of headers) {
             const name = header.name.toLowerCase();
             const value = header.value;

             if (!name || name.length > maxName) {
                 return result("reject",
                     "Malformed or oversized " + side + " header name",
                     "headers.invalid-name");
             }

             if (/[^a-z0-9!#$%&'*+.^_`|~-]/i.test(name)) {
                 return result("reject",
                     "Illegal character in " + side + " header name",
                     "headers.illegal-name");
             }

             // CR/LF/NUL only - real exploit vector
             if (/[\r\n\0]/.test(value)) {
                 return result("reject",
                     side + " header value contains CR/LF/NUL",
                     "headers.invalid-value");
             }

             if (!exempt.has(name) && value.length > maxValue) {
                 return result("reject",
                     side + " header value exceeds length limit",
                     "headers.value-length");
             }

             if (blockedNames.some(b => name === b)) {
                 return result("block",
                     side + " header name is blocked: " + name,
                     "headers.blocked-name");
             }

             if (headerPolicy.rejectOnDuplicateSecurityHeaders &&
                 securityNames.has(name)) {
                 if (seenSecurity.has(name)) {
                     return result("reject",
                         "Duplicate security header: " + name,
                         "headers.duplicate-security");
                 }
                 seenSecurity.set(name, true);
             }
         }

         return null;
     }

     function evaluateAds(url, host, rules) {
         const adPolicy = rules.adsAndTrackers || {};
         if (!adPolicy.enabled) return null;

         if ((adPolicy.blockHosts || []).some(rule => hostMatches(host, rule))) {
             return result("block",
                 "Ad/tracker host matched block list",
                 "adsAndTrackers.blockHosts");
         }

         const href = url.href.toLowerCase();
         if ((adPolicy.blockPatterns || []).some(pattern => {
             const p = String(pattern || "").toLowerCase();
             return p.length >= 8 && href.includes(p);
         })) {
             return result("block",
                 "URL matched ad/tracker pattern",
                 "adsAndTrackers.blockPatterns");
         }

         return null;
     }

     function evaluateRequest(input, rules) {
         const urlText = String(input.url || "");
         if (urlText.length > (rules.limits?.maxUrlLength || 8192)) {
             return result("reject", "URL exceeds configured length limit", "limits.url-length");
         }

         let url;
         try { url = new URL(urlText); }
         catch (_) { return result("reject", "Malformed URL", "url.malformed"); }

         if (!["http:", "https:"].includes(url.protocol)) {
             return result("reject", "Unsupported network protocol", "url.protocol");
         }

         const host = normalizeHost(url.hostname);
         const domains = rules.domains || {};

         if ((domains.allow || []).some(rule => hostMatches(host, rule))) {
             return result("allow", "Explicit domain allow rule", "domains.allow");
         }
         if ((domains.block || []).some(rule => hostMatches(host, rule))) {
             return result("block", "Domain matched block list", "domains.block");
         }

         const adHit = evaluateAds(url, host, rules);
         if (adHit) return adHit;

         const urlPolicy = rules.urls || {};
         if ((urlPolicy.allowPatterns || []).some(p =>
             typeof p === "string" && url.href.includes(p))) {
             return result("allow", "Explicit URL allow rule", "urls.allowPatterns");
         }
         if ((urlPolicy.blockPatterns || []).some(p =>
             typeof p === "string" && url.href.includes(p))) {
             return result("block", "URL matched block pattern", "urls.blockPatterns");
         }

         const headers = normalizeHeaders(input.headers);
         const headerDecision = evaluateHeaders(headers, rules, "request");
         if (headerDecision) return headerDecision;

         const contentType = String(input.contentType || "").split(";")[0].trim().toLowerCase();
         if ((rules.contentTypes?.block || []).some(type =>
             contentType === String(type).toLowerCase())) {
             return result("block", "Content type matched block list", "contentTypes.block");
         }

         const decision = rules.policy?.defaultDecision || "allow";
         if (!VALID_DECISIONS.has(decision)) {
             return result("quarantine", "Invalid default policy decision", "policy.invalid-default");
         }
         return result(decision, "No blocking rule matched", "default");
     }

     function evaluateResponse(input, rules) {
         if (!rules.response?.enabled) {
             return result("allow", "Response inspection disabled", "response.off");
         }

         let url;
         try { url = new URL(String(input.url || "")); }
         catch (_) { return result("reject", "Malformed response URL", "url.malformed"); }

         const host = normalizeHost(url.hostname);
         const adHit = evaluateAds(url, host, rules);
         if (adHit) return adHit;

         const headers = normalizeHeaders(input.headers);
         const headerDecision = evaluateHeaders(headers, rules, "response");
         if (headerDecision) return headerDecision;

         let contentType = "";
         let contentLength = null;
         let hasTE = false;

         for (const h of headers) {
             const n = h.name.toLowerCase();
             if (n === "content-type") {
                 contentType = h.value.split(";")[0].trim().toLowerCase();
             } else if (n === "content-length") {
                 const raw = h.value.trim();
                 const nVal = Number(raw);
                 if (!Number.isFinite(nVal) || nVal < 0 || String(Math.floor(nVal)) !== raw) {
                     return result("reject", "Malformed Content-Length", "response.content-length");
                 }
                 contentLength = nVal;
             } else if (n === "transfer-encoding") {
                 hasTE = true;
                 if (/[\r\n\0]/.test(h.value)) {
                     return result("reject", "Malformed Transfer-Encoding", "response.transfer-encoding");
                 }
             }
         }

         if (rules.response.rejectInvalidContentType && contentType) {
             if (!/^[a-z0-9!#$&^_.+-]+\/[a-z0-9!#$&^_.+-]+$/i.test(contentType)) {
                 return result("reject", "Malformed Content-Type", "response.content-type");
             }
         }

         if ((rules.contentTypes?.block || []).some(type =>
             contentType === String(type).toLowerCase())) {
             return result("block", "Response content type blocked", "contentTypes.block");
         }

         const maxBytes = rules.response.maxBodyHintBytes ||
             rules.limits?.maxResponseBytes || 104857600;
         if (contentLength !== null && contentLength > maxBytes) {
             return result("reject", "Content-Length exceeds configured maximum", "response.size");
         }

         // TE+CL is common enough on real stacks / HTTP2 bridging - off by default
         if (rules.response.rejectTeClConflict && hasTE && contentLength !== null) {
             return result("reject",
                 "Both Transfer-Encoding and Content-Length present",
                 "response.te-cl-conflict");
         }

         return result("allow", "Response passed validation", "response.ok");
     }

     function evaluate(input, rules, phase) {
         try {
             if (!input || !rules || rules.schemaVersion !== 1) {
                 return result(safeFallback(rules),
                     "Invalid input or unsupported rule schema", "engine.invalid-input");
             }
             const p = phase || input.phase || "request";
             return p === "response" ? evaluateResponse(input, rules) : evaluateRequest(input, rules);
         } catch (error) {
             return result(safeFallback(rules),
                 "Policy evaluation failed: " + String(error?.message || error),
                 "engine.exception");
         }
     }

     function logDecision(decision, context) {
         if (!decision || !VALID_DECISIONS.has(decision.decision)) return;
         const entry = {
             component: "WebSentinel",
             decision: decision.decision,
             reason: decision.reason,
             ruleId: decision.ruleId,
             timestamp: decision.timestamp,
             context: {
                 url: String(context?.url || "").slice(0, 2048),
                 method: String(context?.method || "").slice(0, 16),
                 source: String(context?.source || "unknown").slice(0, 64)
             }
         };
         console[decision.decision === "allow" ? "info" : "warn"]("[Web Sentinel]", entry);
     }

     root.WebSentinelPolicy = Object.freeze({
         evaluate: evaluate,
         logDecision: logDecision,
         hostMatches: hostMatches
     });
 })(globalThis);
 '@ | Set-Content ".\sentinel-policy-engine.js" -Encoding UTF8

 # ---- 5) request-guard: cancel only block/reject (not quarantine on response by default) ----
 @'
 "use strict";

 (async function () {
     const PREFIX = "[Web Sentinel]";
     const LOGGER_URL = "http://127.0.0.1:8787/log";
     let rules;

     async function persistViolation(entry) {
         try {
             await fetch(LOGGER_URL, {
                 method: "POST",
                 headers: { "Content-Type": "application/json" },
                 body: JSON.stringify(entry)
             });
         } catch (_) {}
     }

     function log(decision, details, phase) {
         const entry = {
             eventType: "firewall.violation",
             component: "WebSentinelNetwork",
             phase: phase || "request",
             decision: decision.decision,
             reason: decision.reason,
             ruleId: decision.ruleId,
             url: String(details.url || "").slice(0, 2048),
             method: String(details.method || "").slice(0, 16),
             requestType: String(details.type || ""),
             statusCode: details.statusCode || undefined,
             timestampUtc: new Date().toISOString()
         };

         if (decision.decision === "allow") {
             if (rules?.policy?.logAllowed) console.info(PREFIX, entry);
             return;
         }

         console.warn(PREFIX, entry);
         persistViolation(entry);
     }

     function mapHeaders(detailsHeaders) {
         if (!Array.isArray(detailsHeaders)) return [];
         return detailsHeaders.map(h => ({
             name: String(h.name || ""),
             value: String(h.value || "")
         }));
     }

     function inspectBody(body) {
         if (!body) return false;
         const suspicious = /[\u202A-\u202E\u2066-\u2069\u200B-\u200D\uFEFF]/;
         function hasSuspicious(value) {
             if (typeof value !== "string") return false;
             if (suspicious.test(value)) return true;
             if (/\\u(?:202[a-e]|206[6-9]|200[b-d]|feff)/i.test(value)) return true;
             try { return suspicious.test(decodeURIComponent(value)); }
             catch (_) { return false; }
         }
         if (body.formData) {
             for (const values of Object.values(body.formData)) {
                 for (const value of values || []) {
                     if (hasSuspicious(value)) return true;
                 }
             }
         }
         if (body.raw) {
             for (const part of body.raw) {
                 if (!part.bytes) continue;
                 try {
                     const bytes = new Uint8Array(part.bytes);
                     if (bytes.byteLength > 1024 * 1024) continue;
                     if (hasSuspicious(new TextDecoder("utf-8").decode(bytes))) return true;
                 } catch (_) {}
             }
         }
         return false;
     }

     // Hard cancel: block + reject only. Quarantine logs but does not kill page loads.
     function hardCancel(decision) {
         return decision.decision === "block" || decision.decision === "reject";
     }

     try {
         let response = await fetch(browser.runtime.getURL("sentinel-firewall-rules.json")).catch(() => null);
         if (!response || !response.ok) {
             response = await fetch(browser.runtime.getURL("sentinel-rules.json"));
         }
         if (!response.ok) throw new Error("Rules fetch failed: " + response.status);
         rules = await response.json();
         if (rules.schemaVersion !== 1) throw new Error("Unsupported rules schema");
         if (!globalThis.WebSentinelPolicy) throw new Error("Policy engine failed to load");

         const urlFilter = { urls: ["http://*/*", "https://*/*"] };

         browser.webRequest.onBeforeRequest.addListener(
             function (details) {
                 try {
                     const decision = globalThis.WebSentinelPolicy.evaluate({
                         phase: "request",
                         url: details.url,
                         method: details.method,
                         type: details.type,
                         headers: [],
                         contentType: ""
                     }, rules, "request");

                     if (hardCancel(decision)) {
                         log(decision, details, "request");
                         return { cancel: true };
                     }
                     if (decision.decision === "quarantine") {
                         log(decision, details, "request");
                         return { cancel: true };
                     }

                     if (inspectBody(details.requestBody)) {
                         const bodyDecision = {
                             decision: "block",
                             reason: "Request body contains bidi or zero-width controls",
                             ruleId: "unicode.request-body"
                         };
                         log(bodyDecision, details, "request");
                         return { cancel: true };
                     }
                     return {};
                 } catch (error) {
                     const failure = {
                         decision: "quarantine",
                         reason: "Inspection exception: " + String(error?.message || error),
                         ruleId: "engine.exception"
                     };
                     log(failure, details, "request");
                     // Fail closed only on engine exception
                     return { cancel: true };
                 }
             },
             urlFilter,
             ["blocking", "requestBody"]
         );

         browser.webRequest.onBeforeSendHeaders.addListener(
             function (details) {
                 try {
                     const headers = mapHeaders(details.requestHeaders);
                     const decision = globalThis.WebSentinelPolicy.evaluate({
                         phase: "request",
                         url: details.url,
                         method: details.method,
                         type: details.type,
                         headers: headers,
                         contentType: ""
                     }, rules, "request");

                     if (hardCancel(decision)) {
                         log(decision, details, "request-headers");
                         return { cancel: true };
                     }
                     if (decision.decision === "quarantine") {
                         log(decision, details, "request-headers");
                         // Log only for header-phase quarantine (avoid nuking logins)
                         return { requestHeaders: details.requestHeaders };
                     }
                     return { requestHeaders: details.requestHeaders };
                 } catch (error) {
                     const failure = {
                         decision: "quarantine",
                         reason: "Header inspection exception: " + String(error?.message || error),
                         ruleId: "engine.exception"
                     };
                     log(failure, details, "request-headers");
                     return { requestHeaders: details.requestHeaders };
                 }
             },
             urlFilter,
             ["blocking", "requestHeaders"]
         );

         browser.webRequest.onHeadersReceived.addListener(
             function (details) {
                 try {
                     const headers = mapHeaders(details.responseHeaders);
                     const decision = globalThis.WebSentinelPolicy.evaluate({
                         phase: "response",
                         url: details.url,
                         method: details.method,
                         type: details.type,
                         headers: headers,
                         statusCode: details.statusCode,
                         contentType: ""
                     }, rules, "response");

                     if (hardCancel(decision)) {
                         log(decision, details, "response");
                         return { cancel: true };
                     }
                     if (decision.decision === "quarantine") {
                         log(decision, details, "response");
                         return { responseHeaders: details.responseHeaders };
                     }
                     return { responseHeaders: details.responseHeaders };
                 } catch (error) {
                     const failure = {
                         decision: "quarantine",
                         reason: "Response inspection exception: " + String(error?.message || error),
                         ruleId: "engine.exception"
                     };
                     log(failure, details, "response");
                     return { responseHeaders: details.responseHeaders };
                 }
             },
             urlFilter,
             ["blocking", "responseHeaders"]
         );

         console.info(PREFIX, "Network guard registered (request + headers + response).");
         console.info(PREFIX, "Ad/tracker hosts:", (rules.adsAndTrackers?.blockHosts || []).length);
     } catch (error) {
         console.error(PREFIX, "Network guard startup failed; interceptor not active.", error);
     }
 })();
 '@ | Set-Content ".\request-guard.js" -Encoding UTF8

 Write-Host ""
 Write-Host "Fixed."
 Write-Host "  - OOB/PSN restored from J:\backupfw (if files were there)"
 Write-Host "  - Cookie/Set-Cookie no longer trip header length reject"
 Write-Host "  - TE+CL and disposition soft checks disabled"
 Write-Host "  - Broad /ads/ patterns removed (were over-matching)"
 Write-Host "  - Response quarantine no longer cancels page body"
 Write-Host ""
 Write-Host "Reload extension in about:debugging, then hard-refresh github.com"
 Write-Host "Expect: [OOB_PSN] lines + normal page assets loading

 ^C
PS J:\EmojiFirewall\BrowserExtension> ^C
PS J:\EmojiFirewall\BrowserExtension>
PS J:\EmojiFirewall\BrowserExtension>
PS J:\EmojiFirewall\BrowserExtension> Set-ExecutionPolicy -Scope Process Bypass