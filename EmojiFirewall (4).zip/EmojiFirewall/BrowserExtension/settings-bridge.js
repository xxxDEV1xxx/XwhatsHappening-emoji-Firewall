"use strict";

(async function () {
    const KEY = "webSentinelSettings";
    let last = "";

    async function refresh() {
        try {
            const response = await fetch(
                browser.runtime.getURL("sentinel-runtime-settings.json"),
                { cache: "no-store" }
            );
            if (!response.ok) throw new Error("HTTP " + response.status);

            const settings = await response.json();
            if (!settings.firewall || !settings.logging) {
                throw new Error("Invalid settings structure");
            }

            const serialized = JSON.stringify(settings);
            if (serialized !== last) {
                await browser.storage.local.set({ [KEY]: settings });
                last = serialized;
            }
        } catch (e) {
            console.error("[Web Sentinel settings bridge]", String(e));
        }
    }

    await refresh();
    setInterval(refresh, 1000);
})();