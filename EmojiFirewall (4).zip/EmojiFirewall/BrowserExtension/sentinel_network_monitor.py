﻿import datetime
import json
import urllib.request
import urllib.error

LOGGER = "http://127.0.0.1:2222/log"

def emit(event):
    event["timestampUtc"] = datetime.datetime.now(
        datetime.timezone.utc
    ).isoformat()
    data = json.dumps(event).encode("utf-8")
    request = urllib.request.Request(
        LOGGER,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    with urllib.request.urlopen(request, timeout=5) as response:
        print("Logger HTTP status:", response.status)
        print(response.read().decode("utf-8"))

if __name__ == "__main__":
    emit({
        "eventType": "dns.query",
        "queryName": "github.com",
        "source": "sentinel-connectivity-test"
    })
