﻿"use strict";

(function (root) {
    const VALID_DECISIONS = new Set([
        "allow", "block", "quarantine", "reject"
    ]);

    function normalizeHost(host) {
        return String(host || "")
            .trim()
            .toLowerCase()
            .replace(/\.$/, "");
    }

    function hostMatches(host, rule) {
        host = normalizeHost(host);
        rule = normalizeHost(rule).replace(/^\*\./, "");
        return !!host && !!rule &&
            (host === rule || host.endsWith("." + rule));
    }

    function result(decision, reason, ruleId) {
        return {
            decision: decision,
            reason: reason,
            ruleId: ruleId || "default",
            timestamp: new Date().toISOString()
        };
    }

    function evaluate(input, rules) {
        try {
            if (!input || !rules || rules.schemaVersion !== 1) {
                return result(
                    rules?.policy?.onInspectionError || "quarantine",
                    "Invalid input or unsupported rule schema",
                    "engine.invalid-input"
                );
            }

            const policy = rules.policy || {};
            const urlText = String(input.url || "");

            if (urlText.length > (rules.limits?.maxUrlLength || 8192)) {
                return result("reject", "URL exceeds configured length limit",
                    "limits.url-length");
            }

            let url;
            try {
                url = new URL(urlText);
            } catch (_) {
                return result("reject", "Malformed URL", "url.malformed");
            }

            if (!["http:", "https:"].includes(url.protocol)) {
                return result("reject", "Unsupported network protocol",
                    "url.protocol");
            }

            const host = normalizeHost(url.hostname);
            const domains = rules.domains || {};

            if ((domains.allow || []).some(rule => hostMatches(host, rule))) {
                return result("allow", "Explicit domain allow rule",
                    "domains.allow");
            }

            if ((domains.block || []).some(rule => hostMatches(host, rule))) {
                return result("block", "Domain matched block list",
                    "domains.block");
            }

            const adPolicy = rules.adsAndTrackers || {};
            if (adPolicy.enabled &&
                (adPolicy.blockHosts || []).some(rule => hostMatches(host, rule))) {
                return result("block", "Ad/tracker host matched block list",
                    "adsAndTrackers.blockHosts");
            }

            const urlPolicy = rules.urls || {};
            if ((urlPolicy.allowPatterns || []).some(pattern =>
                typeof pattern === "string" && url.href.includes(pattern))) {
                return result("allow", "Explicit URL allow rule",
                    "urls.allowPatterns");
            }

            if ((urlPolicy.blockPatterns || []).some(pattern =>
                typeof pattern === "string" && url.href.includes(pattern))) {
                return result("block", "URL matched block pattern",
                    "urls.blockPatterns");
            }

            const headerPolicy = rules.headers || {};
            const headers = Array.isArray(input.headers) ? input.headers : [];

            if (headers.length >
                (headerPolicy.maxCount || rules.limits?.maxHeaderCount || 100)) {
                return result("reject", "Header count exceeds configured limit",
                    "headers.count");
            }

            for (const header of headers) {
                const name = String(header?.name || "").trim().toLowerCase();
                const value = String(header?.value || "");

                if (!name || /[^a-z0-9!#$%&'*+.^_`|~-]/i.test(name)) {
                    return result("reject", "Malformed header name",
                        "headers.invalid-name");
                }

                if (/[\r\n\0]/.test(value)) {
                    return result("reject", "Header value contains forbidden controls",
                        "headers.invalid-value");
                }

                if (value.length > (headerPolicy.maxValueLength || 16384)) {
                    return result("reject", "Header value exceeds configured limit",
                        "headers.value-length");
                }

                if ((headerPolicy.blockedNames || []).some(blocked =>
                    name === String(blocked).toLowerCase())) {
                    return result("block", "Header name is explicitly blocked",
                        "headers.blocked-name");
                }
            }

            const contentType = String(input.contentType || "")
                .split(";")[0].trim().toLowerCase();

            if ((rules.contentTypes?.block || []).some(type =>
                contentType === String(type).toLowerCase())) {
                return result("block", "Content type matched block list",
                    "contentTypes.block");
            }

            const decision = policy.defaultDecision || "allow";
            if (!VALID_DECISIONS.has(decision)) {
                return result("quarantine", "Invalid default policy decision",
                    "policy.invalid-default");
            }

            return result(decision, "No blocking rule matched", "default");
        } catch (error) {
            const fallback = rules?.policy?.onInspectionError || "quarantine";
            const safeFallback = VALID_DECISIONS.has(fallback)
                ? fallback : "quarantine";

            return result(safeFallback,
                "Policy evaluation failed: " + String(error?.message || error),
                "engine.exception");
        }
    }

    function logDecision(decision, context) {
        if (!decision || !VALID_DECISIONS.has(decision.decision)) {
            console.error("[Web Sentinel] Invalid decision record", decision);
            return;
        }

        const entry = {
            component: "WebSentinel",
            decision: decision.decision,
            reason: decision.reason,
            ruleId: decision.ruleId,
            timestamp: decision.timestamp,
            context: {
                url: String(context?.url || "").slice(0, 2048),
                method: String(context?.method || "").slice(0, 16),
                source: String(context?.source || "unknown").slice(0, 64)
            }
        };

        const method = decision.decision === "allow" ? "info" : "warn";
        console[method]("[Web Sentinel]", entry);
    }

    root.WebSentinelPolicy = Object.freeze({
        evaluate: evaluate,
        logDecision: logDecision,
        hostMatches: hostMatches
    });
})(globalThis);
