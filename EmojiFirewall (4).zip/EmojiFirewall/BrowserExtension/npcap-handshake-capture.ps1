﻿$ErrorActionPreference = "Stop"
$dll = "$env:WINDIR\System32\Npcap\wpcap.dll"
if (-not (Test-Path $dll)) { throw "Npcap wpcap.dll not found." }

$source = @"
using System;
using System.IO;
using System.Net;
using System.Text;
using System.Runtime.InteropServices;

public static class NpcapHandshakeCapture {
    [StructLayout(LayoutKind.Sequential)]
    public struct PcapIf {
        public IntPtr next, name, description, addresses;
        public uint flags;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct TimeVal {
        public int sec;
        public int usec;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct PcapHeader {
        public TimeVal ts;
        public uint caplen;
        public uint len;
    }

    [DllImport(@"$dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int pcap_findalldevs(ref IntPtr list, byte[] errbuf);

    [DllImport(@"$dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern void pcap_freealldevs(IntPtr list);

    [DllImport(@"$dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern IntPtr pcap_open_live(
        string device, int snaplen, int promisc, int timeout, byte[] errbuf);

    [DllImport(@"$dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int pcap_datalink(IntPtr p);

    [DllImport(@"$dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int pcap_next_ex(
        IntPtr p, out IntPtr header, out IntPtr data);

    [DllImport(@"$dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern IntPtr pcap_geterr(IntPtr p);

    [DllImport(@"$dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern IntPtr pcap_dump_open(IntPtr p, string filename);

    [DllImport(@"$dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern void pcap_dump(
        IntPtr dumper, IntPtr header, IntPtr data);

    [DllImport(@"$dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern int pcap_dump_flush(IntPtr dumper);

    [DllImport(@"$dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern void pcap_dump_close(IntPtr dumper);

    [DllImport(@"$dll", CallingConvention=CallingConvention.Cdecl)]
    public static extern void pcap_close(IntPtr p);

    static string PtrString(IntPtr p) {
        return p == IntPtr.Zero ? "" : Marshal.PtrToStringAnsi(p);
    }

    public static string[] Devices() {
        byte[] err = new byte[256];
        IntPtr list = IntPtr.Zero;
        int rc = pcap_findalldevs(ref list, err);
        if (rc != 0)
            throw new Exception("Npcap adapter enumeration failed: " +
                Encoding.ASCII.GetString(err).TrimEnd('\0'));

        var result = new System.Collections.Generic.List<string>();
        try {
            IntPtr cur = list;
            while (cur != IntPtr.Zero) {
                PcapIf item = (PcapIf)Marshal.PtrToStructure(cur, typeof(PcapIf));
                string name = PtrString(item.name);
                string desc = PtrString(item.description);
                if (name.Length > 0)
                    result.Add(name + "\t" + desc);
                cur = item.next;
            }
        } finally {
            pcap_freealldevs(list);
        }
        return result.ToArray();
    }

    static ushort U16(byte[] b, int p) {
        return (ushort)((b[p] << 8) | b[p + 1]);
    }

    static bool ParsePacket(byte[] b, int link, out string jsonBody, out bool synAck) {
        jsonBody = null;
        synAck = false;
        int off = 0;
        ushort ether = 0;

        if (link == 1) {
            if (b.Length < 14) return false;
            ether = U16(b, 12);
            off = 14;
            while (ether == 0x8100 || ether == 0x88a8 || ether == 0x9100) {
                if (b.Length < off + 4) return false;
                ether = U16(b, off + 2);
                off += 4;
            }
        } else if (link == 12 || link == 101) {
            if (b.Length < 1) return false;
            int ver = b[0] >> 4;
            ether = ver == 4 ? (ushort)0x0800 : ver == 6 ? (ushort)0x86dd : (ushort)0;
        } else if (link == 0) {
            if (b.Length < 5) return false;
            off = 4;
            int ver = b[off] >> 4;
            ether = ver == 4 ? (ushort)0x0800 : ver == 6 ? (ushort)0x86dd : (ushort)0;
        } else {
            return false;
        }

        string src, dst;
        int tcp;
        string ipVersion;

        if (ether == 0x0800) {
            if (b.Length < off + 20 || (b[off] >> 4) != 4) return false;
            int ihl = (b[off] & 15) * 4;
            if (ihl < 20 || b.Length < off + ihl) return false;
            if (b[off + 9] != 6) return false;
            if ((U16(b, off + 6) & 0x1fff) != 0) return false;

            src = new IPAddress(new byte[] { b[off+12], b[off+13], b[off+14], b[off+15] }).ToString();
            dst = new IPAddress(new byte[] { b[off+16], b[off+17], b[off+18], b[off+19] }).ToString();
            tcp = off + ihl;
            ipVersion = "IPv4";
        } else if (ether == 0x86dd) {
            if (b.Length < off + 40 || (b[off] >> 4) != 6) return false;
            src = new IPAddress(Copy(b, off + 8, 16)).ToString();
            dst = new IPAddress(Copy(b, off + 24, 16)).ToString();
            int next = b[off + 6];
            int pos = off + 40;
            int count = 0;

            while (next != 6 && count++ < 12) {
                if (next == 0 || next == 43 || next == 60 || next == 135) {
                    if (b.Length < pos + 2) return false;
                    int n = b[pos];
                    int size = (b[pos + 1] + 1) * 8;
                    next = n; pos += size;
                } else if (next == 44) {
                    if (b.Length < pos + 8) return false;
                    int frag = U16(b, pos + 2);
                    if ((frag & 0xfff8) != 0) return false;
                    next = b[pos]; pos += 8;
                } else if (next == 51) {
                    if (b.Length < pos + 2) return false;
                    int n = b[pos];
                    int size = (b[pos + 1] + 2) * 4;
                    next = n; pos += size;
                } else {
                    return false;
                }
                if (pos > b.Length) return false;
            }
            if (next != 6) return false;
            tcp = pos;
            ipVersion = "IPv6";
        } else {
            return false;
        }

        if (b.Length < tcp + 20) return false;
        int flags = b[tcp + 13];
        bool syn = (flags & 0x02) != 0;
        bool ack = (flags & 0x10) != 0;
        if (!syn) return false;

        synAck = ack;
        int sport = U16(b, tcp);
        int dport = U16(b, tcp + 2);

        // Body fields only (timestamp added by caller for unified schema)
        jsonBody =
            "\"eventType\":\"tcp.handshake\"," +
            "\"event\":\"" + (ack ? "SYN_ACK" : "SYN") + "\"," +
            "\"ipVersion\":\"" + ipVersion + "\"," +
            "\"sourceIp\":\"" + src + "\"," +
            "\"sourcePort\":" + sport + "," +
            "\"destinationIp\":\"" + dst + "\"," +
            "\"destinationPort\":" + dport + "," +
            "\"tcpFlags\":" + flags;
        return true;
    }

    static byte[] Copy(byte[] b, int off, int len) {
        byte[] r = new byte[len];
        Buffer.BlockCopy(b, off, r, 0, len);
        return r;
    }

    public static void Run(string device, string jsonlPath) {
        byte[] err = new byte[256];
        IntPtr p = pcap_open_live(device, 65535, 1, 250, err);
        if (p == IntPtr.Zero)
            throw new Exception("Cannot open adapter: " +
                Encoding.ASCII.GetString(err).TrimEnd('\0'));

        try {
            int link = pcap_datalink(p);
            if (link != 1 && link != 0 && link != 12 && link != 101)
                throw new Exception("Unsupported link type " + link +
                    "; choose an Ethernet or loopback adapter.");

            Console.WriteLine("Capturing SYN/SYN-ACK only. Ctrl+C stops.");
            Console.WriteLine("Unified log: " + jsonlPath);

            while (true) {
                IntPtr hp, dp;
                int rc = pcap_next_ex(p, out hp, out dp);
                if (rc == 0) continue;
                if (rc == -2) break;
                if (rc < 0)
                    throw new Exception("Capture error: " + PtrString(pcap_geterr(p)));

                PcapHeader h = (PcapHeader)Marshal.PtrToStructure(hp, typeof(PcapHeader));
                if (h.caplen < 1 || h.caplen > 1048576) continue;

                byte[] bytes = new byte[(int)h.caplen];
                Marshal.Copy(dp, bytes, 0, bytes.Length);

                string body;
                bool synAck;
                if (!ParsePacket(bytes, link, out body, out synAck))
                    continue;

                DateTimeOffset stamp =
                    DateTimeOffset.FromUnixTimeSeconds(h.ts.sec)
                    .AddTicks((long)h.ts.usec * 10);

                string line = "{\"timestampUtc\":\"" + stamp.ToString("o") + "\"," + body + "}";
                using (var mutex = new System.Threading.Mutex(false, "WebSentinelUnifiedLog")) {
                    bool acquired = false;
                    try {
                        acquired = mutex.WaitOne();
                        File.AppendAllText(
                            jsonlPath,
                            line + Environment.NewLine,
                            new UTF8Encoding(false)
                        );
                    } finally {
                        if (acquired) mutex.ReleaseMutex();
                    }
                }
                Console.WriteLine(stamp.ToString("HH:mm:ss.fff") +
                    (synAck ? " SYN-ACK " : " SYN     ") + body);
            }
        } finally {
            pcap_close(p);
        }
    }
}
"@

Add-Type -TypeDefinition $source

Write-Host "Npcap adapters:"
$devices = [NpcapHandshakeCapture]::Devices()
if (-not $devices -or $devices.Count -eq 0) {
    throw "Npcap found no adapters."
}
for ($i = 0; $i -lt $devices.Count; $i++) {
    Write-Host ("[{0}] {1}" -f $i, $devices[$i])
}

$pick = Read-Host "Enter adapter number"
if ($pick -notmatch '^\d+$' -or [int]$pick -ge $devices.Count) {
    throw "Invalid adapter number."
}
$adapter = $devices[[int]$pick].Split("`t")[0]

# FIXED unified log (handshakes + violations)
$jsonl = Join-Path (Join-Path $PSScriptRoot "logs") "web-sentinel.jsonl"
if (-not (Test-Path $jsonl)) {
    New-Item -ItemType File -Path $jsonl | Out-Null
}

[NpcapHandshakeCapture]::Run($adapter, $jsonl)

