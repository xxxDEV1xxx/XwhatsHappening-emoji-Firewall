﻿"use strict";

const EF_COOKIE_POLICY_KEY = "emojiFirewallCookiePolicy";

const EF_COOKIE_DEFAULTS = Object.freeze({
  mode: "deny-by-default",
  allowedDomains: []
});

function efNormalizeDomain(value) {
  const domain = String(value || "").trim().toLowerCase()
    .replace(/^\*\./, "").replace(/\.$/, "");

  if (!domain || domain.includes("/") || domain.includes(":") ||
      domain.includes("*") || /\s/.test(domain)) {
    throw new Error("Enter a hostname, such as example.com");
  }

  return domain;
}

async function efGetCookiePolicy() {
  const result = await browser.storage.local.get(EF_COOKIE_POLICY_KEY);
  return {
    ...EF_COOKIE_DEFAULTS,
    ...(result[EF_COOKIE_POLICY_KEY] || {})
  };
}

async function efAllowCookieDomain(value) {
  const domain = efNormalizeDomain(value);
  const policy = await efGetCookiePolicy();

  if (!policy.allowedDomains.includes(domain)) {
    policy.allowedDomains.push(domain);
  }

  await browser.storage.local.set({
    [EF_COOKIE_POLICY_KEY]: policy
  });

  return policy;
}

async function efRemoveCookieDomain(value) {
  const domain = efNormalizeDomain(value);
  const policy = await efGetCookiePolicy();

  policy.allowedDomains = policy.allowedDomains.filter(
    item => item !== domain
  );

  await browser.storage.local.set({
    [EF_COOKIE_POLICY_KEY]: policy
  });

  return policy;
}

async function efIsCookieDomainAllowed(value) {
  const host = efNormalizeDomain(value);
  const policy = await efGetCookiePolicy();

  return policy.allowedDomains.some(domain =>
    host === domain || host.endsWith("." + domain)
  );
}

if (typeof globalThis.browser !== "undefined") {
  globalThis.EmojiFirewallCookiePolicy = Object.freeze({
    get: efGetCookiePolicy,
    allow: efAllowCookieDomain,
    remove: efRemoveCookieDomain,
    isAllowed: efIsCookieDomainAllowed
  });
}
