﻿$ErrorActionPreference = "Stop"
$logDir = Join-Path $PSScriptRoot "logs"
New-Item -ItemType Directory -Force $logDir | Out-Null
$logFile = Join-Path $logDir "web-sentinel.jsonl"
$port = 8787
$settingsPath = 'J:\EmojiFirewall\WebSentinelLauncher\settings.json'

# Ensure file exists
if (-not (Test-Path $logFile)) {
    New-Item -ItemType File -Path $logFile | Out-Null
}

$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://127.0.0.1:$port/")
$listener.Start()
Write-Host "Web Sentinel logger listening on http://127.0.0.1:$port/"
Write-Host "Log file: $logFile"
Write-Host "POST /log  body=JSON object  |  GET /health  |  Ctrl+C to stop"

function Test-LoggingAllows([string]$eventType) {
    $map = @{
        'tcp.handshake'      = 'tcpHandshakes'
        'dns.query'          = 'dns'
        'network.inbound'    = 'incomingConnections'
        'firewall.violation' = 'firewallDecisions'
    }
    try {
        $log = ([System.IO.File]::ReadAllText($settingsPath) | ConvertFrom-Json).logging
        if ($log.enabled -ne $true) { return $false }
        if (-not $map.ContainsKey($eventType)) { return $true }
        return ($log.($map[$eventType]) -eq $true)
    } catch { return $false }
}

function Write-Event([hashtable]$obj) {
    if (-not $obj.ContainsKey("timestampUtc") -or [string]::IsNullOrWhiteSpace($obj["timestampUtc"])) {
        $obj["timestampUtc"] = (Get-Date).ToUniversalTime().ToString("o")
    }
    $line = ($obj | ConvertTo-Json -Compress -Depth 8)
    # File append is atomic enough for single-writer + occasional concurrent appends on Windows for line sizes used here
    [System.IO.File]::AppendAllText($logFile, $line + [Environment]::NewLine)
}

try {
    while ($listener.IsListening) {
        $ctx = $listener.GetContext()
        $req = $ctx.Request
        $res = $ctx.Response
        try {
            if ($req.HttpMethod -eq "GET" -and $req.Url.AbsolutePath -eq "/health") {
                $bytes = [Text.Encoding]::UTF8.GetBytes('{"ok":true}')
                $res.StatusCode = 200
                $res.ContentType = "application/json"
                $res.OutputStream.Write($bytes, 0, $bytes.Length)
            }
            elseif ($req.HttpMethod -eq "POST" -and $req.Url.AbsolutePath -eq "/log") {
                $reader = New-Object System.IO.StreamReader($req.InputStream, $req.ContentEncoding)
                $body = $reader.ReadToEnd()
                $reader.Close()

                if ([string]::IsNullOrWhiteSpace($body) -or $body.Length -gt 65536) {
                    $res.StatusCode = 400
                } else {
                    try {
                        $parsed = $body | ConvertFrom-Json
                        $ht = @{}
                        foreach ($p in $parsed.PSObject.Properties) {
                            $ht[$p.Name] = $p.Value
                        }
                        # Only accept handshake + violation style events
                        $etype = [string]$ht["eventType"]
                        if ($etype -notin @("tcp.handshake", "firewall.violation")) {
                            $res.StatusCode = 400
                        } elseif (-not (Test-LoggingAllows $etype)) {
                            $res.StatusCode = 204
                        } else {
                            Write-Event $ht
                            $res.StatusCode = 204
                        }
                    } catch {
                        $res.StatusCode = 400
                    }
                }
            }
            else {
                $res.StatusCode = 404
            }
        } catch {
            $res.StatusCode = 500
        } finally {
            $res.Close()
        }
    }
} finally {
    $listener.Stop()
    $listener.Close()
}