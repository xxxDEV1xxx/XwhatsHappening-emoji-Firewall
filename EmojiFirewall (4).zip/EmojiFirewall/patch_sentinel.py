import sys
from pathlib import Path

p = Path(sys.argv[1] if len(sys.argv) > 1 else
         r"J:\EmojiFirewall\BrowserExtension\sentinel-policy.js")

raw = p.read_bytes()
bom = raw.startswith(b"\xef\xbb\xbf")
text = raw.decode("utf-8-sig")

OLD = "if (config.version !== 1 ||"
NEW = "if ((config.schemaVersion ?? config.version) !== 1 ||"

if NEW in text:
    sys.exit("already applied, nothing changed")
if text.count(OLD) != 1:
    sys.exit(f"ABORT: anchor found {text.count(OLD)}x (need 1)")

bak = p.with_suffix(p.suffix + ".before-schemaversion")
if not bak.exists():
    bak.write_bytes(raw)

text = text.replace(OLD, NEW)
p.write_bytes((b"\xef\xbb\xbf" if bom else b"") + text.encode("utf-8"))
print("patched:", p)
print("backup :", bak)