﻿using System.Net;
using System.Text.Json.Nodes;
using Titanium.Web.Proxy;
using Titanium.Web.Proxy.EventArguments;
using Titanium.Web.Proxy.Models;

static string StripWhatsHappening(string json)
{
    JsonNode? root = JsonNode.Parse(json);

    if (root is not JsonObject obj ||
        obj["data"] is not JsonObject data ||
        data["explore_sidebar"] is not JsonObject sidebar ||
        sidebar["timeline"] is not JsonObject timeline ||
        timeline["instructions"] is not JsonArray instructions)
    {
        return json;
    }

    bool changed = false;

    foreach (JsonNode? node in instructions)
    {
        if (node is not JsonObject instruction ||
            instruction["type"]?.GetValue<string>() != "TimelineAddEntries" ||
            instruction["entries"] is not JsonArray entries)
        {
            continue;
        }

        for (int i = entries.Count - 1; i >= 0; i--)
        {
            if (entries[i] is not JsonObject entry)
                continue;

            string? headerText =
                entry["content"]?["header"]?["text"]?.GetValue<string>();

            if (string.Equals(
                headerText,
                "Whatâ€™s happening",
                StringComparison.Ordinal))
            {
                entries.RemoveAt(i);
                changed = true;
            }
        }
    }

    return changed ? root.ToJsonString() : json;
}

static async Task RunProxyAsync()
{
    var proxy = new ProxyServer();
    proxy.ExceptionFunc = ex => Console.WriteLine($"PROXY EXC: {ex}");
    var endpoint = new ExplicitProxyEndPoint(
        IPAddress.Loopback,
        8080,
        decryptSsl: true);
    proxy.BeforeRequest += async (sender, e) =>
    {
        var uri = e.HttpClient.Request.RequestUri;

        CookiePolicy.LogRequestCookies(uri?.Host ?? "?", e.HttpClient.Request);

        if (uri is not null &&
            (uri.Host.Equals("x.com", StringComparison.OrdinalIgnoreCase) ||
             uri.Host.EndsWith(".x.com", StringComparison.OrdinalIgnoreCase)))
        {
            Console.WriteLine(
                $"REQUEST {e.HttpClient.Request.Method} {uri}");
        }
    };
    proxy.BeforeResponse += async (sender, e) =>
    {
        try
        {
            var request = e.HttpClient.Request;
            var uri = request.RequestUri;

            if (uri is not null)
            {
                CookiePolicy.Enforce(uri.Host, e.HttpClient.Response);
            }

            if (uri is null ||
                !string.Equals(uri.Host, "x.com",
                    StringComparison.OrdinalIgnoreCase) ||
                !uri.AbsolutePath.EndsWith(
                    "/ExploreSidebar",
                    StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            var response = e.HttpClient.Response;

            if (response.StatusCode != 200 ||
                response.ContentType is null ||
                !response.ContentType.Contains(
                    "json", StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            string body = await e.GetResponseBodyAsString(
                CancellationToken.None);

            string filtered;

            try
            {
                filtered = StripWhatsHappening(body);
            }
            catch (System.Text.Json.JsonException)
            {
                Console.WriteLine("TARGET: response was not valid JSON; unchanged.");
                return;
            }

            if (!string.Equals(body, filtered, StringComparison.Ordinal))
            {
                e.SetResponseBodyString(filtered);
                Console.WriteLine(
                    $"{DateTime.Now:T} FILTERED {uri.AbsolutePath}");
            }
            else
            {
                Console.WriteLine(
                    $"{DateTime.Now:T} TARGET matched, no change made.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Response processing error: {ex.Message}");
        }
    };

    proxy.AddEndPoint(endpoint);

    // Generate a local proxy certificate if one does not already exist.
    // This does NOT automatically trust or install it.
    proxy.CertificateManager.CertificateEngine =
        Titanium.Web.Proxy.Network.CertificateEngine.DefaultWindows;

    proxy.CertificateManager.EnsureRootCertificate();

    proxy.Start();

    Console.WriteLine("SidebarFirewall proxy listening on 127.0.0.1:8080");
    Console.WriteLine("Press Enter to stop.");
    Console.ReadLine();

    proxy.Stop();
}

if (args.Length == 1 && args[0] == "--proxy")
{
    try
    {
        await RunProxyAsync();
        return 0;
    }
    catch (Exception ex)
    {
        Console.Error.WriteLine($"PROXY FAILED: {ex}");
        return 1;
    }
}

if (args.Length != 2)
{
    Console.Error.WriteLine(
        "Usage: SidebarFirewall <input.json> <output.json>");
    Console.Error.WriteLine(
        "   or: SidebarFirewall --proxy");
    return 2;
}

try
{
    string input = File.ReadAllText(args[0]);
    string output = StripWhatsHappening(input);

    File.WriteAllText(args[1], output);

    Console.WriteLine(input == output
        ? "UNCHANGED: target module not found or response shape differed."
        : "FILTERED: removed the What's happening module.");

    return 0;
}
catch (Exception ex)
{
    Console.Error.WriteLine($"FAILED: {ex.Message}");
    return 1;
}

